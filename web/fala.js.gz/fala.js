
(() => {
  "use strict";
  const statusLine = document.getElementById("statusLine");
  const caption = document.getElementById("caption");
  const lastAnswer = document.getElementById("lastAnswer");
  const accessLine = document.getElementById("accessLine");
  const orb = document.getElementById("orb");
  const form = document.getElementById("askForm");
  const extras = document.getElementById("extras");
  const moreButton = document.getElementById("moreButton");
  const loginForm = document.getElementById("loginForm");
  const input = document.getElementById("askInput");
  const logoutButton = document.getElementById("logoutButton");
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const OWNER_TOKEN_KEY = "jarvis-owner-token-v1";
  const LAST_LOGIN_KEY = "jarvis-last-login";
  const REMEMBER_KEY = "jarvis-remember-login-v1";
  const OWNER_IDLE_KEY = "jarvis-owner-last-active";
  const LISTEN_KEY = "jarvis-fala-listen";
  // A versão de verdade mora no <meta> do fala.html, que o gateway lê para
  // responder /status. Escrita à mão aqui, ela ficava para trás e o aviso de
  // "atualização disponível" nunca sumia: o cliente sempre se achava velho.
  const SHELL_VERSION = (() => {
    const tag = document.querySelector('meta[name="jarvis-shell"]');
    const valor = tag?.getAttribute("content")?.trim();
    return valor || "20261105-modo3";
  })();
  const WEB_VOLUME_KEY = "jarvis-web-volume";
  // Variantes fonéticas mínimas: "jarbas" é nome de pessoa e "ja viu" é
  // homófono de frase comum — as duas fontes de disparo falso relatadas.
  // O reconhecedor em pt-BR escreve o nome de vários jeitos ("já vis",
  // "Jarbas", "Gervais"): só "jarvis" exato deixava o app surdo ao nome.
  const WAKE_ALT = "j[aá]\\s?r?\\s?v[ií][sz]|jarvius|jarbis|jarbas|jarves|javis|garvis|gervais|gervis|djarvis|iarvis|charvis|xarvis";
  const WAKE_NAME = new RegExp("\\b(?:" + WAKE_ALT + ")\\b");
  const WAKE_CALL = /(?:^|\s)(?:oi|ola|eae|eai|e ai|ei|hey|fala|eita|alou|iae)(?:\s+|$)/g;
  const WAKE_ONLY = /^(?:oi|ola|eae|eai|e ai|ei|hey|fala|eita|alou|iae)$/;
  const appMode = new URLSearchParams(window.location.search).get("app") === "1"
    || window.matchMedia("(display-mode: standalone)").matches;
  let busy = false;
  // Quando o JARVIS falou por último. "sim"/"não" só contam como
  // resposta dentro desta janela — fora dela é conversa de outra
  // pessoa na sala, com o microfone armado.
  let ultimaFalaEm = 0;
  const JANELA_RESPOSTA_CURTA_MS = 20_000;
  let keepListening = false;
  let armed = false;
  let armUntil = 0;
  let speaking = false;
  let recHandle = null;
  let pendingHeard = "";
  let heardTimer = 0;
  let listenPainted = false;
  let lastAckAt = 0;
  let lastAsked = "";
  let lastAskedAt = 0;
  let lastOpenAt = 0;
  let stayQuiet = false;
  let askQueue = [];
  let speakRunId = 0;
  let meeting = false;
  let clickWait = 0;
  let parkTimer = 0;
  let lastStatus = null;
  let voiceLocalOk = null;
  let micPermission = "";
  let debugTimer = 0;

  if (appMode) document.documentElement.classList.add("app-mode");
  document.documentElement.classList.toggle("needs-login", !ownerToken());
  document.documentElement.classList.toggle("signed-in", Boolean(ownerToken()));

  const creator = () => window.JarvisCreator?.name?.() || "Theo Lorentz Padilha";

  function ownerToken() {
    try { return window.localStorage.getItem(OWNER_TOKEN_KEY) || ""; } catch { return ""; }
  }

  function rememberLoginEnabled() {
    try { return window.localStorage.getItem(REMEMBER_KEY) !== "0"; } catch { return true; }
  }

  function persistSession(token, username) {
    try {
      if (token) window.localStorage.setItem(OWNER_TOKEN_KEY, token);
      if (username) window.localStorage.setItem(LAST_LOGIN_KEY, username);
      window.localStorage.setItem(REMEMBER_KEY, appMode || rememberLoginEnabled() ? "1" : "0");
      window.localStorage.setItem(OWNER_IDLE_KEY, String(Date.now()));
    } catch { /* private mode */ }
    try { nativeHandlers()?.jarvisWindow.postMessage("token:" + (token || "")); } catch { /* web */ }
  }

  function apiHeaders() {
    const headers = { "Content-Type": "application/json" };
    const token = ownerToken();
    if (token) headers["X-Jarvis-Owner-Token"] = token;
    return headers;
  }

  async function postJson(path, payload) {
    let lastError = "Sem rede.";
    for (let attempt = 0; attempt < 2; attempt += 1) {
      try {
        const response = await fetch(path, {
          method: "POST",
          headers: apiHeaders(),
          body: JSON.stringify(payload),
          signal: window.AbortSignal?.timeout ? window.AbortSignal.timeout(path === "/command" ? (payload && payload.attachments ? 40000 : 22000) : 14000) : undefined,
        });
        const data = await response.json().catch(() => ({ ok: false, error: "Resposta inválida." }));
        if (response.status >= 500 && attempt === 0) {
          lastError = data.error || "Servidor ocupado.";
          await new Promise((resolve) => window.setTimeout(resolve, 350));
          continue;
        }
        return { response, data };
      } catch (error) {
        lastError = navigator.onLine === false ? "Você está offline." : "Falha de rede.";
        if (attempt === 0) await new Promise((resolve) => window.setTimeout(resolve, 350));
      }
    }
    return { response: { status: 0, ok: false }, data: { ok: false, error: lastError, retryable: true } };
  }

  function say(title, detail) {
    statusLine.textContent = title;
    if (detail !== undefined) caption.textContent = detail;
  }

  // ---------- Soundbar em volta do orb ----------
  // O dono pediu o medidor de voz do JARVIS: as barras em volta da esfera
  // dançando enquanto ele fala. Texto girando foi tentado antes e ele recusou
  // ("eu só queria o soundbar"). A fala continua na legenda abaixo.
  function paintRing(_text, falando) {
    const stage = document.getElementById("orbStage");
    if (!stage) return;
    stage.classList.toggle("is-speaking", Boolean(falando));
  }

  function limparRing() {
    paintRing("", false);
  }

  function showAnswer(text) {
    const clean = String(text || "").replace(/\s+/g, " ").trim();
    if (!clean) return;
    lastAnswer.hidden = false;
    lastAnswer.textContent = clean.length > 180 ? `${clean.slice(0, 177)}…` : clean;
    holdReply();
  }

  function showAnswerLink(prefix, href, label) {
    lastAnswer.hidden = false;
    lastAnswer.textContent = "";
    if (prefix) lastAnswer.append(document.createTextNode(`${prefix} `));
    const link = document.createElement("a");
    link.href = href;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.textContent = label;
    lastAnswer.append(link);
    holdReply();
  }

  function applyPersona(_label) {
    document.documentElement.dataset.persona = "jarvis";
  }

  function clearStaleSession() {
    try { window.localStorage.removeItem(OWNER_TOKEN_KEY); } catch { /* private */ }
    try { nativeHandlers()?.jarvisWindow.postMessage("token:"); } catch { /* web */ }
  }

  function paintHome() {
    // No ensaio quem manda na legenda é o roteiro: repintar o "Diga Jarvis"
    // a cada passo piscava por cima da fala sendo lida.
    if (ensaioLigado) return;
    // O #hint ficou oculto de propósito: a linha "Neste Mac você entra só agora"
    // não dizia nada útil. O elemento continua no HTML por causa do contrato
    // verificado em 10_TESTES/fala_overlay_test.py.
    if (ownerToken()) {
      say("JARVIS", "Diga Jarvis.");
      return;
    }
    say("JARVIS", appMode ? "A mesma conta do site." : "Diga Jarvis.");
  }

  function renderAccess(label, signedIn) {
    accessLine.textContent = label;
    applyPersona(label);
    const inSession = Boolean(signedIn);
    document.documentElement.classList.toggle("signed-in", inSession);
    document.documentElement.classList.toggle("needs-login", !inSession);
    logoutButton.hidden = !inSession;
    loginForm.querySelector("#loginUser").hidden = inSession;
    loginForm.querySelector("#loginPass").hidden = inSession;
    loginForm.querySelector("button[type='submit']").hidden = inSession;
    const remember = document.getElementById("rememberLogin");
    if (remember) remember.closest("label").hidden = inSession;
    paintHome();
  }

  function noteStatus(data) {
    if (!data || typeof data !== "object") return;
    lastStatus = data;
  }

  async function refreshAccess() {
    if (!ownerToken()) {
      renderAccess("Visitante", false);
      return;
    }
    try {
      const data = await fetch("/status", { headers: apiHeaders() }).then((row) => row.json());
      noteStatus(data);
      const mode = data.access?.mode;
      if (mode !== "owner" && mode !== "member") {
        clearStaleSession();
        renderAccess("Visitante", false);
        return;
      }
      const power = data.power_profile?.mode === "jarvis_3x" || mode === "owner";
      renderAccess(power ? "JARVIS · 3×" : "Conta JARVIS", true);
    } catch {
      renderAccess("Sessão", Boolean(ownerToken()));
    }
  }

  function webVolume() {
    try {
      const raw = Number(window.localStorage.getItem(WEB_VOLUME_KEY));
      if (Number.isFinite(raw) && raw >= 0 && raw <= 1) return raw;
    } catch { /* private mode */ }
    return 1;
  }

  function playBlob(blob) {
    return new Promise((resolve) => {
      const url = URL.createObjectURL(blob);
      const audio = new Audio(url);
      audio.volume = webVolume();
      // O dono descreveu "pausas demoradas e muito brancas": cada frase é um
      // áudio e o `ended` chega depois do silêncio que o encoder gravou no fim
      // do arquivo. Encostar o próximo fio no anterior costura a fala.
      audio.preservesPitch = true;
      const finish = () => {
        orb.classList.remove("speaking");
        URL.revokeObjectURL(url);
        resolve();
      };
      audio.addEventListener("ended", finish, { once: true });
      audio.addEventListener("error", finish, { once: true });
      orb.classList.add("speaking");
      audio.play().catch(finish);
    });
  }

  function nativeHandlers() {
    try { return window.webkit && window.webkit.messageHandlers; } catch { return null; }
  }

  function hasNativeSpeak() {
    return Boolean(nativeHandlers() && nativeHandlers().jarvisSpeak);
  }

  function hasNativeListen() {
    return Boolean(nativeHandlers() && nativeHandlers().jarvisListen);
  }

  function muteMicForSpeech() {
    speaking = true;
    window.clearTimeout(heardTimer);
    pendingHeard = "";
    try { recHandle && recHandle.stop(); } catch { /* already stopped */ }
  }

  function stopSpeak() {
    speakRunId += 1;
    try { nativeHandlers()?.jarvisSpeak.postMessage("stop"); } catch { /* web */ }
    speaking = false;
  }

  // O que o JARVIS está dizendo agora, sem acento: o mic ouve o alto-falante,
  // e "…modo Homem de Ferro" / "…modo fullscreen?" na boca dele casam com os
  // gatilhos do roteiro e reentravam a cena ou cortavam a própria fala.
  let falaAtualFolded = "";
  let falaTerminouEm = 0;
  const CAUDA_ECO_MS = 1200;

  function ecoDaPropriaFala(text) {
    if (!falaAtualFolded) return false;
    if (!speaking && Date.now() - falaTerminouEm > CAUDA_ECO_MS) return false;
    const ouvido = foldSpeech(text);
    if (!ouvido) return false;
    if (falaAtualFolded.includes(ouvido)) return true;
    const palavras = ouvido.split(/\s+/).filter(Boolean);
    if (palavras.length < 3) return false;
    const dentro = palavras.filter((p) => falaAtualFolded.includes(p)).length;
    return dentro / palavras.length >= 0.8;
  }

  function unmuteMicAfterSpeech() {
    speaking = false;
    falaTerminouEm = Date.now();
    // O anel continua com a última frase por um instante: some junto com a
    // fala, não no mesmo frame (senão pisca).
    window.setTimeout(() => { if (!speaking) limparRing(); }, 1200);
    if (!stayQuiet) keepArmed();
    try { nativeHandlers()?.jarvisListen.postMessage("resume"); } catch { /* web */ }
    if (keepListening && !hasNativeListen()) listenLoop();
    drainQueue();
    // Fim da fala é o momento de esconder. Sem isto, um pedido que terminou
    // com speaking=true não reagendava o park em lugar nenhum e a janela
    // ficava aberta para sempre.
    if (!busy && !stayQuiet) parkSoon();
  }

  // Mesma regra do app nativo: frases por . ! ? … e quebra de linha; frase
  // <8 chars gruda na seguinte. Texto sem separador vira frase única —
  // caminho comum, igual ao comportamento antigo.
  function pushSpeechPart(parts, current) {
    const piece = current.trim();
    if (piece) parts.push(piece);
  }

  function speechSentences(text) {
    const parts = [];
    let current = "";
    for (const ch of text) {
      if (ch === "." || ch === "!" || ch === "?" || ch === "…") {
        current += ch;
        pushSpeechPart(parts, current);
        current = "";
      } else if (ch === "\n" || ch === "\r") {
        pushSpeechPart(parts, current);
        current = "";
      } else {
        current += ch;
      }
    }
    pushSpeechPart(parts, current);
    if (parts.length <= 1) return parts;
    const merged = [];
    let index = 0;
    // Cada frase é um áudio separado, e entre dois áudios o player para e
    // espera o próximo chegar: é isso que soa como "pausa branca". Juntar
    // frases curtas na mesma requisição corta o número de emendas. 8 era
    // agressivo demais para o ritmo que o dono quer; 22 mantém o fraseado
    // e tira o silêncio no meio da fala.
    const MIN_PART_CHARS = 22;
    while (index < parts.length) {
      let piece = parts[index];
      while (piece.length < MIN_PART_CHARS && index + 1 < parts.length) {
        index += 1;
        piece += ` ${parts[index]}`;
      }
      merged.push(piece);
      index += 1;
    }
    return merged;
  }

  // Web: busca o blob da frase 1 e toca; em paralelo pré-busca a próxima
  // (no máximo 1 fetch em voo, como no app) e encadeia playBlob sequencial.
  // Frase com erro é pulada e a fila segue; o unmute fica no .finally de speak.
  // Frases lengthas ("Bem-vindo ao modo Homem de Ferro, senhor.") esperavam o
  // áudio inteiro antes de soar: 2 a 3,3s de silêncio medidos no servidor
  // local. A primeira frase de cada fala vai inteira (é ela que o dono ouve
  // primeiro); as seguintes são divididas na vírgula para o som começar
  // enquanto o resto ainda é sintetizado.
  const DIVIDE_NA_VIRGULA = 80;

  function primeiroPedacoCurto(chunks) {
    if (chunks.length !== 1) return chunks;
    const frase = chunks[0];
    if (frase.length <= DIVIDE_NA_VIRGULA) return chunks;
    // Só vale a primeira vírgula: dividir em todas picava a frase em pedaços
    // sem sentido ("às três," / "quatro e cinco da tarde") e cada áudio novo
    // é uma emenda que se ouve.
    const corte = frase.search(/,\s/);
    if (corte < 12) return chunks;
    const inicio = frase.slice(0, corte + 1).trim();
    const resto = frase.slice(corte + 1).trim();
    // O resto precisa continuar sendo fala: um "senhor." de 7 chars não é.
    return resto.length >= 12 ? [inicio, resto] : chunks;
  }

  function speakChunksQueue(chunks, persona) {
    chunks = primeiroPedacoCurto(chunks);
    let next = 0;
    const ready = [];
    let fetching = false;
    let waiting = false;
    let finish = null;
    let semVozLocal = false;
    // Cancelamento: enterQuiet/stopSpeak incrementam o run global e a fila
    // inteira abandona o resto (antes "fica quieto" continuava falando).
    const myRun = speakRunId;

    const aborted = () => myRun !== speakRunId || stayQuiet;
    const stopIfAborted = () => {
      if (aborted()) {
        ready.length = 0;
        return true;
      }
      return false;
    };

    const fetchNext = () => {
      if (stopIfAborted()) {
        if (!fetching && !ready.length) finish();
        return;
      }
      if (fetching || next >= chunks.length) return;
      const chunk = chunks[next];
      next += 1;
      fetching = true;
      let pending;
      try {
        pending = Promise.resolve(window.JarvisLocalVoice?.speakBlob(chunk, { persona }));
      } catch {
        pending = Promise.reject(new Error("speakBlob"));
      }
      pending.then(
        (blob) => {
          // Sem áudio a fila seguia em silêncio e o JARVIS parecia travado:
          // registro a falha e falo pelo navegador em vez de não falar nada.
          if (!blob) semVozLocal = true;
          if (blob && !aborted()) ready.push(blob);
        },
        () => { semVozLocal = true; /* frase falha: pula */ }
      ).then(() => {
        fetching = false;
        fetchNext();
        if (waiting) {
          waiting = false;
          playNext();
        }
      });
    };

    const playNext = () => {
      if (stopIfAborted()) {
        if (!fetching) finish();
        return;
      }
      if (!ready.length) {
        if (fetching || next < chunks.length) {
          fetchNext();
          waiting = true;
          return;
        }
        // Fila vazia porque a voz local não devolveu áudio: aviso na tela em vez
        // de deixar o JARVIS mudo sem ninguém entender por quê. Não uso a voz
        // do navegador de propósito — o /fala é só a voz local do JARVIS.
        if (semVozLocal && !aborted()) {
          semVozLocal = false;
          say("Sem voz.", "O servidor local de voz não respondeu. Abra com debug=1 para ver.");
        }
        finish();
        return;
      }
      const blob = ready.shift();
      fetchNext();
      Promise.resolve()
        .then(() => playBlob(blob))
        .catch(() => {})
        .then(() => { if (!aborted()) playNext(); else finish(); });
    };

    return new Promise((resolveQueue) => {
      finish = resolveQueue;
      playNext();
    });
  }

  // Fala atrasada que respeita "dorme", quieto, park e um novo pedido: nada
  // de rearmar o microfone que o usuário mandou calar.
  let pendingSpeech = null;

  function speakAfterDelay(partes, delayMs) {
    const fila = Array.isArray(partes) ? partes : [partes];
    const token = ++speechGeneration;
    // Pré-aquece durante a espera: sintetizar as quatro partes do quadro leva
    // ~8,6s e a espera é de 9s. Sem isto a primeira parte só começa a ser
    // gerada no fim da espera e a voz entra atrasada, por cima da música.
    // O servidor tem cache, então o speak() depois acha pronto.
    if (delayMs > 1500 && window.JarvisLocalVoice?.speakBlob) {
      for (const parte of fila) {
        window.JarvisLocalVoice.speakBlob(parte).catch(() => {});
      }
    }
    return new Promise((resolve) => {
      const timer = window.setTimeout(async () => {
        for (const parte of fila) {
          if (token !== speechGeneration || stayQuiet) return resolve();
          await speak(parte);
        }
        resolve();
      }, delayMs);
      speakCancelHandlers.add(() => { window.clearTimeout(timer); resolve(); });
    });
  }

  function cancelPendingSpeech() {
    speechGeneration += 1;
    for (const cancel of speakCancelHandlers) cancel();
    speakCancelHandlers.clear();
    pendingSpeech = null;
  }

  let speechGeneration = 0;
  const speakCancelHandlers = new Set();

  function speak(text) {
    const clip = String(text || "").replace(/\s+/g, " ").trim().slice(0, 400);
    if (!clip) return Promise.resolve();
    // Marca a hora antes de falar: a partir daqui uma resposta curta do
    // dono ("sim", "não") conta como resposta a esta fala.
    ultimaFalaEm = Date.now();
    falaAtualFolded = foldSpeech(clip);
    paintRing(clip, true);
    muteMicForSpeech();
    if (hasNativeSpeak()) {
      return new Promise((resolve) => {
        const timer = window.setTimeout(resolve, 20_000);
        window.__jarvisOnSpeakDone = () => {
          window.clearTimeout(timer);
          window.__jarvisOnSpeakDone = null;
          resolve();
        };
        try { nativeHandlers().jarvisSpeak.postMessage(clip); } catch { resolve(); }
      }).finally(() => unmuteMicAfterSpeech());
    }
    return speakChunksQueue(speechSentences(clip), "jarvis")
      .catch(() => {})
      .finally(() => unmuteMicAfterSpeech());
  }

  let lastOpenUrl = "";
  let lastError = "";
  let lastCommand = "";

  function openTarget(url) {
    const href = String(url || "");
    if (!href) return false;
    const now = Date.now();
    if (href === lastOpenUrl && now - lastOpenAt < 8000) return true;
    lastOpenUrl = href;
    lastOpenAt = now;
    // No app nativo o `window.open` sempre devolve null (a janela nova não é
    // criada), e o aviso "Popup bloqueado" aparecia no meio da tela em vez do
    // site. Lá o link vai pelo handler nativo, que abre no navegador.
    const nativo = window.webkit?.messageHandlers?.jarvisOpen;
    if (nativo) {
      try {
        nativo.postMessage(href);
        return true;
      } catch (e) { /* cai no window.open */ }
    }
    const popup = window.open(href, "_blank", "noopener,noreferrer");
    if (popup) return true;
    showAnswerLink("Popup bloqueado.", href, "Toque para abrir");
    return false;
  }

  function localClock() {
    return new Date().toLocaleString("pt-BR", {
      weekday: "long", day: "numeric", month: "long", hour: "2-digit", minute: "2-digit",
    });
  }

  // Abrir app do Mac não existe client-side: manda pelo gateway, que roda
  // open_application com allowlist (APPLICATION_ALIASES) no Mac dele.
  function openAppOnMac(app, label) {
    cancelPark();
    nativeWindow("touch");
    postJson("/command", { command: `abrir aplicativo ${app}`, strength: "auto" }).then(({ data }) => {
      const message = data.ok === false
        ? (data.error || "Não consegui abrir o app.")
        : (data.message || `Abrindo o ${label}.`);
      say(data.ok === false ? "Não." : "Senhor.", "");
      showAnswer(message);
      if (!stayQuiet) speak(spokenReply(message));
    });
  }

  // App do Mac: a janela é borderless, então o handler nativo cobre o frame
  // da tela. Web puro: Fullscreen API, com aviso claro se o gesto for cobrado.
  function toggleFullscreen() {
    if (nativeHandlers()) {
      nativeWindow("fullscreen");
      return;
    }
    const doc = document;
    if (doc.fullscreenElement || doc.webkitFullscreenElement) {
      const exit = doc.exitFullscreen || doc.webkitExitFullscreen;
      if (exit) exit.call(doc);
      say("Saindo.", "Tela cheia desligada.");
      return;
    }
    const root = doc.documentElement;
    const request = root.requestFullscreen || root.webkitRequestFullscreen;
    if (!request) {
      say("Tela cheia.", "Este navegador não suporta.");
      speak("Este navegador não suporta tela cheia.");
      return;
    }
    Promise.resolve(request.call(root)).then(() => {
      say("Tela cheia.", "Diga tela cheia de novo para sair.");
    }).catch(() => {
      say("Tela cheia.", "O navegador bloqueou. Toque na página e tente de novo.");
      speak("O navegador bloqueou a tela cheia. Toque na página e tente de novo.");
    });
  }

  function remainderAfter(value, match) {
    const rest = String(match || "").replace(/\s+(?:pra mim|para mim|por favor)$/i, "").trim();
    if (!rest || /^(?:o|a|o youtube|youtube|mapa|maps)$/i.test(rest)) return "";
    return rest;
  }

  function isMacSpotifyCommand(value) {
    const text = String(value || "").toLocaleLowerCase("pt-BR");
    // Faixas do catálogo disparam sem a palavra "spotify".
    if (/\b(?:homem\s+de\s+ferro|iron\s+man|back\s+in\s+black|spotify:track:)\b/.test(text)) return true;
    if (!/\bspotify\b/.test(text)) return false;
    // No app nativo o Spotify é SEMPRE o app do Mac; abrir o web player no
    // navegador não toca nada e ainda cobre a tela de abas.
    if (hasNativeListen()) return true;
    if (/\b(?:com|paus|to(?:c|q)|play|pr[oó]xim|volum|status|aleat|shuffle|repet)\w*/.test(text)) return true;
    return false;
  }

  function resolveOpen(text) {
    const value = String(text || "").toLocaleLowerCase("pt-BR").trim();
    if (isMacSpotifyCommand(value)) return null;
    const google = value.match(/^(?:google|pesquisa no google|busca no google)\s+(.+)/);
    if (google) return { url: `https://www.google.com/search?q=${encodeURIComponent(google[1])}`, label: "Google" };
    const youtubeSearch = value.match(/^(?:pesquisa|busca|procura)\s+(?:no\s+)?youtube\s+(.+)/)
      || value.match(/^(?:abre|abrir|abra|inici(?:a|e|ar))\s+(?:o\s+)?youtube\s+(?:de|do|da|das|dos|sobre)\s+(.+)/)
      || value.match(/^(?:abre|abrir|abra|inici(?:a|e|ar))\s+(?:o\s+)?youtube\s+(.+)/);
    if (youtubeSearch) {
      const query = remainderAfter(value, youtubeSearch[1]);
      if (query) return { url: `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`, label: "YouTube" };
    }
    const mapsSearch = value.match(/^(?:como chegar(?:\s+(?:em|no|na|ao|à|a))?)\s+(.+)/)
      || value.match(/^(?:abre|abrir|abra)\s+(?:o\s+)?(?:mapa|maps)\s+(?:de|para|em|no|na)\s+(.+)/);
    if (mapsSearch) {
      const query = remainderAfter(value, mapsSearch[1]);
      if (query) return { url: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`, label: "Maps" };
    }
    const opening = /\b(?:abre|abrir|abra|inici(?:a|e|ar))\b/.test(value);
    if (!opening) return null;
    // Navegadores são apps do Mac, não abas: o gateway tem open_application
    // com allowlist (aliases em api/index.py). "navegador" cai no Safari,
    // o padrão do dono.
    const appTargets = [
      [/\bchrome\b|\bgoogle\s+chrome\b/, "Google Chrome", "Chrome"],
      [/\bsafari\b/, "Safari", "Safari"],
      [/\bedge\b|\bmicrosoft\s+edge\b/, "Microsoft Edge", "Edge"],
      [/\bbrave\b/, "Brave Browser", "Brave"],
      [/\b(?:navegador|browser)\b/, "Safari", "navegador"],
    ];
    for (const [pattern, app, label] of appTargets) {
      if (pattern.test(value)) return { app, label };
    }
    const targets = [
      [/\bwhatsapp\b/, "https://web.whatsapp.com", "WhatsApp"],
      [/\byoutube\b/, "https://www.youtube.com", "YouTube"],
      [/\bspotify\b/, "https://open.spotify.com", "Spotify"],
      [/\b(?:mapa|maps|como chegar)\b/, "https://maps.google.com", "Google Maps"],
      [/\bcalend[aá]rio|agenda\b/, "https://calendar.google.com", "Agenda"],
      [/\b(?:o\s+)?gmail\b/, "https://mail.google.com", "Gmail"],
      [/\bgithub\b/, "https://github.com", "GitHub"],
      [/\b(?:instagram|insta)\b/, "https://www.instagram.com", "Instagram"],
      [/\b(?:chat\s*gpt|chatgpt)\b/, "https://chatgpt.com", "ChatGPT"],
      [/\b(?:google\s+)?drive\b/, "https://drive.google.com", "Drive"],
      [/\bdiscord\b/, "https://discord.com/app", "Discord"],
      [/\bnotion\b/, "https://www.notion.so", "Notion"],
      [/\btwitter\b|(?:abre|abrir|abra)\s+(?:o\s+)?x\b/, "https://x.com", "X"],
      [/\bgoogle\b/, "https://www.google.com", "Google"],
    ];
    for (const [pattern, url, label] of targets) {
      if (pattern.test(value)) return { url, label };
    }
    return null;
  }

  function revealLogin() {
    extras.hidden = false;
    moreButton.textContent = "fechar";
    document.getElementById("loginUser")?.focus();
    say("Login.", "Mesma conta do cockpit.");
  }

  // Mesmo contrato dos modos do cockpit (jarvis.js): verde = plano,
  // vermelho = bypass/sempre-aceitar, modo normal apaga tudo.
  function voiceModeFor(value) {
    const clean = String(value || "").trim().replace(/^jarvis[,\s]+/i, "");
    if (/^(?:vai|vá|va)\s+dormir\.?$|^(?:entrar?\s+no\s+)?modo\s+plano\.?$|^plano\.?$/i.test(clean)) {
      return {
        mode: "plan",
        title: "Modo plano.",
        detail: "Borda verde: só planejo, nada executo sem aprovação.",
        speak: "Modo plano ativado. Borda verde: só planejo, nada executo sem a sua aprovação.",
      };
    }
    if (/^bypass(?:\s+permissions?)?\.?$|^pular\s+permiss(?:ões|oes|ão|ao)\.?$/i.test(clean)) {
      return {
        mode: "bypass",
        title: "Bypass de permissões.",
        detail: "Borda vermelha: executo sem confirmar cada passo.",
        speak: "Bypass de permissões ativado. Borda vermelha: executo sem confirmar cada passo.",
      };
    }
    if (/^always\s+accept(?:ed)?\.?$|^(?:aceite|aceitar)\s+tudo\.?$|^sempre\s+aceite\.?$/i.test(clean)) {
      return {
        mode: "bypass",
        title: "Sempre aceitar.",
        detail: "Borda vermelha: aprovo tudo automaticamente.",
        speak: "Sempre aceitar ativado. Borda vermelha: aprovo tudo automaticamente.",
      };
    }
    if (/^modo\s+normal\.?$|^acordar?\.?$|^sai(?:r)?\s+do\s+modo\.?$|^despertar\.?$/i.test(clean)) {
      return { mode: "normal", title: "Modo normal.", detail: "Borda apagada.", speak: "De volta ao modo normal." };
    }
    return null;
  }

  function applyVoiceMode(mode) {
    document.body.classList.remove("jarvis-mode-plan", "jarvis-mode-bypass");
    if (mode === "plan") document.body.classList.add("jarvis-mode-plan");
    else if (mode === "bypass") document.body.classList.add("jarvis-mode-bypass");
    try {
      if (mode && mode !== "normal") window.localStorage.setItem("jarvis-assistant-mode", mode);
      else window.localStorage.removeItem("jarvis-assistant-mode");
    } catch { /* private */ }
  }

  function localAction(text) {
    const value = String(text || "").toLocaleLowerCase("pt-BR");
    const cena = cenaDoRoteiro(value);
    if (cena) return cena;
    if (/^(?:entrar|login|fazer login|conectar)$/.test(value.trim())) {
      return { run: () => revealLogin(), speak: "" };
    }
    if (/\btela\s+(?:cheia|inteira)\b/.test(value)) {
      return { run: () => toggleFullscreen(), speak: "" };
    }
    // Modos explícitos do dono: borda verde (plano) / vermelha (bypass,
    // sempre-aceitar) na tela inteira, com confirmação falada — sem IA.
    const voiceMode = voiceModeFor(value.trim());
    if (voiceMode) {
      return {
        run: () => applyVoiceMode(voiceMode.mode),
        title: voiceMode.title,
        detail: voiceMode.detail,
        speak: voiceMode.speak,
      };
    }
    const opened = resolveOpen(value);
    if (opened) {
      if (opened.app) {
        return {
          run: () => openAppOnMac(opened.app, opened.label),
          title: "Abrindo.",
          detail: opened.label,
          speak: `Abrindo o ${opened.label}.`,
        };
      }
      return {
        run: () => openTarget(opened.url),
        title: "Abrindo.",
        detail: opened.label,
        speak: `Abrindo o ${opened.label}.`,
      };
    }
    if (/\bhoras?\b|\bque dia\b|\bdata de hoje\b/.test(value)) {
      return {
        run: () => {
          const now = localClock();
          say("Agora.", now);
          showAnswer(now);
        },
        speak: () => `São ${new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}, senhor.`,
      };
    }
    if (/^copia/.test(value)) {
      return {
        run: () => {
          const textToCopy = lastAnswer.textContent || "";
          if (textToCopy && navigator.clipboard?.writeText) navigator.clipboard.writeText(textToCopy);
          say("Copiado.", textToCopy || "Nada ainda.");
        },
        speak: "",
      };
    }
    if (/\bcockpit\b|\bjanela grande\b/.test(value)) {
      return { run: () => { window.location.href = "/"; }, speak: "" };
    }
    return null;
  }

  function isQuietAsk(text) {
    const folded = foldSpeech(text);
    if (/^(?:silencio|quieto)$/.test(folded)) return true;
    return /\b(?:fica\s+quieto|fica\s+calado|cala\s+a\s+boca|para\s+de\s+falar|modo\s+foco|nao\s+me\s+perturba|estou\s+ocupado)\b/.test(folded);
  }

  // Sem wake armado, só um comando que COMEÇA com verbo de ação passa —
  // "contém youtube" fazia conversa casual virar comando.
  function looksLikeCommand(text) {
    const folded = foldSpeech(text);
    if (!folded) return false;
    // Resposta curta a uma pergunta do JARVIS ("sim", "pode", "não") é
    // comando: o modo Homem de Ferro termina perguntando se pode abrir algo,
    // e sem isto o dono teria que dizer "Jarvis, sim" para responder.
    // Só vale logo depois de uma fala dele: numa reunião com o mic armado,
    // um "sim" solto não pode virar pedido.
    if (/^(?:sim|pode|manda|bora|claro|isso|vai|nao|deixa|agora nao)$/.test(folded)) {
      return Date.now() - ultimaFalaEm < JANELA_RESPOSTA_CURTA_MS;
    }
    if (folded.length < 3) return false;
    if (WAKE_NAME.test(folded)) return true;
    // As cenas do roteiro não começam com verbo: "Jarvis entra no modo
    // Homem de Ferro", "dá uma prévia do próximo vídeo". Sem esta linha a
    // fala caía no modelo como pergunta e ele respondia outra coisa.
    if (cenaDoRoteiro(folded)) return true;
    return /^(?:abre|abrir|abra|fecha|fechar|toca|toque|paus|play|pesquisa|busca|procura|volume|proximo|proxima|silencio|quieto|cala|copia|cockpit|repete|de novo|outra vez|analisa|analise|olha|veja|que horas|horas|que dia|data|bateria|clima|tempo|previsao|cotacao|dolar|euro|bitcoin|specs|hardware|noticias|analisa isso|tela cheia|tela inteira|entra|entrar|modo|da|previa)\b/.test(folded);
  }

  function expandCommands(text) {
    const folded = foldSpeech(text);
    if (!/\b(?:abre|abrir|abra|inici(?:a|e|ar))\b/.test(folded)) return [text];
    const catalog = [
      ["whatsapp", "abre o whatsapp"],
      ["youtube", "abre o youtube"],
      ["spotify", "abre o spotify"],
      ["gmail", "abre o gmail"],
      ["instagram", "abre o instagram"],
      ["github", "abre o github"],
      ["discord", "abre o discord"],
      ["notion", "abre o notion"],
      ["drive", "abre o drive"],
      ["agenda", "abre a agenda"],
      ["calendario", "abre a agenda"],
      ["maps", "abre o maps"],
      ["mapa", "abre o maps"],
      ["google", "abre o google"],
      ["chrome", "abre o chrome"],
      ["safari", "abre o safari"],
      ["edge", "abre o edge"],
      ["brave", "abre o brave"],
      ["navegador", "abre o navegador"],
    ];
    const hits = [];
    const seen = new Set();
    const finder = /whatsapp|youtube|spotify|gmail|instagram|github|discord|notion|drive|agenda|calendario|maps|mapa|google|\bchrome\b|\bsafari\b|\bedge\b|\bbrave\b|\bnavegador\b/g;
    let match = finder.exec(folded);
    while (match) {
      const key = match[0];
      const row = catalog.find(([name]) => name === key);
      if (row && !seen.has(row[1])) {
        seen.add(row[1]);
        hits.push(row[1]);
      }
      match = finder.exec(folded);
    }
    if (hits.includes("abre o maps")) {
      const google = hits.indexOf("abre o google");
      if (google >= 0) hits.splice(google, 1);
    }
    if (hits.includes("abre o drive")) {
      const google = hits.indexOf("abre o google");
      if (google >= 0) hits.splice(google, 1);
    }
    return hits.length >= 2 ? hits : [text];
  }

  function enterQuiet() {
    stayQuiet = true;
    cancelPendingSpeech();
    speakRunId += 1;
    armed = false;
    askQueue = [];
    try { nativeHandlers()?.jarvisSpeak.postMessage("stop"); } catch { /* web */ }
    parkNow();
    say("Quieto.", "Diga Jarvis quando quiser.");
  }

  function enqueue(command) {
    const clip = String(command || "").replace(/\s+/g, " ").trim();
    if (!clip || stayQuiet) return;
    if (askQueue.length >= 4) return;
    const folded = foldSpeech(clip);
    if (folded === foldSpeech(lastAsked)) return;
    if (askQueue.some((item) => foldSpeech(item) === folded)) return;
    askQueue.push(clip);
  }

  function drainQueue() {
    if (busy || speaking || stayQuiet) return;
    const next = askQueue.shift();
    if (next) ask(next);
  }

  function hasNativeSee() {
    return Boolean(nativeHandlers() && nativeHandlers().jarvisSee);
  }

  function isLookAsk(text) {
    const folded = foldSpeech(text);
    if (!folded) return false;
    if (/\b(?:o que|oq|que)\b.{0,24}\b(?:estou|to|eu to|eu estou)\s+vendo\b/.test(folded)) return true;
    if (/\b(?:analis|olh|veja|ve |leia|le )\w*.{0,48}\b(?:isso|aqui|tela|pagina|navegador|site|print)\b/.test(folded)) return true;
    if (/\b(?:o que|oq)\s+(?:eu\s+)?(?:faco|fazer)\s+(?:com\s+)?(?:isso|aqui)\b/.test(folded)) return true;
    return /^(?:analisa|analise|olha|olhe|veja|ve|le|leia)(?:\s+(?:isso|aqui|a tela))?$/.test(folded);
  }

  function seeScreen(command) {
    if (hasNativeSee()) {
      say("Olhando.", "Vou ver a tela.");
      cancelPark();
      nativeWindow("touch");
      window.__jarvisOnScreen = (raw) => {
        window.__jarvisOnScreen = null;
        const dataUrl = String(raw || "");
        if (dataUrl === "denied") {
          say("Tela.", "Ajustes → Privacidade → Gravação de Tela → JARVIS.");
          speak("Preciso da permissão de gravação de tela.");
          return;
        }
        if (!dataUrl.startsWith("data:image")) {
          say("Tela.", "Não consegui ver. Tente de novo.");
          speak("Não consegui ver a tela.");
          return;
        }
        ask(command || "analisa o que está na tela e me diz o que fazer", {
          type: "image/jpeg",
          name: "tela.jpg",
          data_url: dataUrl,
        });
      };
      try { nativeHandlers().jarvisSee.postMessage("screen"); } catch {
        say("Tela.", "Não consegui ver.");
      }
      return;
    }
    seeScreenWeb(command);
  }

  // Web puro: getDisplayMedia pede a tela/janela ao dono, captura UM frame e
  // segue o mesmo fluxo de attachment do app nativo.
  async function seeScreenWeb(command) {
    if (!navigator.mediaDevices?.getDisplayMedia) {
      say("Tela.", "Este navegador não permite captura de tela.");
      speak("Este navegador não permite que eu veja a tela.");
      return;
    }
    say("Olhando.", "Escolha a tela ou a janela para compartilhar.");
    let stream;
    try {
      stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
    } catch {
      say("Tela.", "Permita a captura de tela para eu analisar.");
      speak("Permita a captura de tela para eu analisar.");
      return;
    }
    try {
      const dataUrl = await frameFromStream(stream);
      ask(command || "analisa o que está na tela e me diz o que fazer", {
        type: "image/jpeg",
        name: "tela.jpg",
        data_url: dataUrl,
      });
    } catch {
      say("Tela.", "Não consegui ver. Tente de novo.");
      speak("Não consegui ver a tela.");
    }
  }

  function frameFromStream(stream) {
    return new Promise((resolve, reject) => {
      const video = document.createElement("video");
      video.muted = true;
      video.playsInline = true;
      video.srcObject = stream;
      const cleanup = () => {
        try { video.pause(); } catch { /* já parado */ }
        video.srcObject = null;
        stream.getTracks().forEach((track) => track.stop());
      };
      video.addEventListener("error", () => { cleanup(); reject(new Error("frame")); }, { once: true });
      video.addEventListener("loadedmetadata", () => {
        video.play().then(() => {
          const width = Math.min(1280, video.videoWidth || 1280);
          const scale = width / Math.max(video.videoWidth, 1);
          const canvas = document.createElement("canvas");
          canvas.width = Math.max(1, Math.round(video.videoWidth * scale));
          canvas.height = Math.max(1, Math.round(video.videoHeight * scale));
          const ctx = canvas.getContext("2d");
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const dataUrl = canvas.toDataURL("image/jpeg", 0.72);
          cleanup();
          if (!dataUrl.startsWith("data:image")) {
            reject(new Error("frame"));
            return;
          }
          resolve(dataUrl);
        }, (error) => { cleanup(); reject(error); });
      }, { once: true });
    });
  }

  async function ask(text, attachment) {
    const command = String(text || "").trim();
    if (!command) return;
    if (busy) {
      enqueue(command);
      return;
    }
    busy = true;
    lastCommand = command;
    // Um pedido novo cancela a fala agendada do pedido anterior: o modo
    // Homem de Ferro agenda o quadro para 9s, e dizer outra coisa nesse
    // meio fazia as duas falas se sobreporem (com o microfone mudo).
    cancelPendingSpeech();
    cancelPark();
    try {
      if (isQuietAsk(command)) enterQuiet();
      if (navigator.onLine === false) {
        const local = localAction(command);
        if (local) {
          local.run();
          const spoken = typeof local.speak === "function" ? local.speak() : local.speak;
          if (spoken && !stayQuiet) await speak(spoken);
          return;
        }
        say("Offline.", "Sem internet para o restante.");
        if (!stayQuiet) await speak("Sem internet");
        return;
      }
      const local = attachment ? null : localAction(command);
      if (local) {
        local.run();
        if (local.title) say(local.title, local.detail || command);
        const spoken = typeof local.speak === "function" ? local.speak() : local.speak;
        if (spoken && !stayQuiet) await speak(spoken);
        return;
      }
      say("Pensando.", command);
      const payload = {
        command: attachment
          ? `${command}. Isto é um print da tela onde o JARVIS está; diga o que aparece e o que eu devo fazer agora.`
          : command,
        strength: ownerToken() ? "maximum" : "auto",
      };
      if (attachment) payload.attachments = [attachment];
      if (attachment) nativeWindow("touch");
      const { response, data } = await postJson("/command", payload);
      const message = data.message || data.error || "Sem resposta.";
      lastError = data.ok === false ? message : "";
      const retry = document.getElementById("retryButton");
      if (retry) retry.hidden = !lastError;
      if (response.status === 401 || data.pairing_required) {
        clearStaleSession();
        renderAccess("Visitante", false);
        revealLogin();
        cancelPark();
        nativeWindow("focus");
      }
      // Agenda: o painel holográfico abre dentro do JARVIS, sobre o orbe.
      // O servidor marca client_action "agenda" quando o pedido é sobre ela.
      if (data.client_action === "agenda" || data.agenda_panel === true) {
        if (window.__jarvisSonda) {
          window.__jarvisSonda(`agenda pedida: painel=${Boolean(document.getElementById("hudAgenda"))} aberto=${hudAberto}`);
        }
        abrirHud();
        if (window.__jarvisSonda) {
          window.__jarvisSonda(`depois de abrirHud: aberto=${hudAberto} hidden=${document.getElementById("hudAgenda")?.hidden}`);
        }
      }
      // Set pessoal pode pedir tema ("muda pro claro"): é do app, não do Mac.
      if (data.client_action === "theme" && data.theme) {
        const value = data.theme === "light" ? "light" : "dark";
        document.documentElement.dataset.theme = value;
        try { localStorage.setItem("jarvis-theme", value); } catch (e) { /* web */ }
      }
      // Tela pedida ("abre o Google na TV"): o navegador não escolhe tela, mas
      // o Mac sabe. Pelo app nativo isso vai para o worker; na web pura não há
      // como mandar a aba para outro monitor, então abrimos aqui mesmo.
      let opened = false;
      if (data.client_action === "open_url" && data.open_url) {
        // Projetos do dono aparecem DENTRO do JARVIS, quase em tela cheia.
        // Só o que não é projeção (Spotify, WhatsApp, Google) abre fora.
        const projetado = window.__jarvisAbrirSite && window.__jarvisAbrirSite(data.open_url);
        // No arranjo do dono a web do JARVIS fica na segunda tela e os
        // projetos abrem na terceira. Sem tela pedida, o projeto vai para lá.
        const daTelaDoProjeto = /github\.com/i.test(String(data.open_url));
        const tela = data.open_display || (daTelaDoProjeto ? "projetor" : "");
        if (projetado) {
          opened = true;
        } else {
          if (tela && window.webkit?.messageHandlers?.jarvisDisplay) {
            try {
              window.webkit.messageHandlers.jarvisDisplay.postMessage(
                JSON.stringify({ url: data.open_url, tela })
              );
              opened = true;
            } catch { opened = false; }
          }
          if (!opened) opened = openTarget(data.open_url);
        }
      }
      if (data.client_action === "quiet_mode" || isQuietAsk(command)) {
        enterQuiet();
        if (response.status === 429) {
          say("Limite.", message);
          return;
        }
        say("Quieto.", "Diga Jarvis quando quiser.");
        return;
      }
      if (response.status === 429) {
        say("Limite.", message);
        return;
      }
      if (!stayQuiet && hasNativeSpeak()) {
        try { nativeHandlers().jarvisSpeak.postMessage("stop"); } catch { /* web */ }
      }
      say(data.ok === false ? "Não." : "Senhor.", "");
      if (data.status_real === "free_web_search_unavailable") {
        showAnswerLink(message, `https://www.google.com/search?q=${encodeURIComponent(command)}`, "Buscar no Google");
      } else if (!opened) {
        showAnswer(message);
      }
      // `spoken` é o texto que o servidor preparou para a voz; sem ele, cai no
      // recorte de duas frases da mensagem de tela.
      const spokenText = data.spoken ? String(data.spoken) : spokenReply(message);
      if (!stayQuiet) await speak(spokenText);
      // Segunda fala: o modo espera a música entrar antes de ler o quadro.
      // A espera NÃO pode segurar o `busy`: com ele travado, "pausa a música"
      // dito nesse intervalo ficava na fila e só rodava depois da leitura.
      if (!stayQuiet && (data.spoken_later || Array.isArray(data.spoken_parts))) {
        const atraso = Math.max(0, Math.min(30_000, Number(data.spoken_delay_ms) || 9000));
        // Em partes, cada uma curta: a pergunta final não pode ser cortada
        // por uma agenda longa.
        const partes = Array.isArray(data.spoken_parts) && data.spoken_parts.length
          ? data.spoken_parts.map((p) => String(p)).filter(Boolean)
          : [String(data.spoken_later)];
        const agendado = speakAfterDelay(partes, atraso);
        pendingSpeech = agendado;
        // Ao terminar (ou falhar), libera a marca: senão parkSoon() fica
        // bloqueado para sempre e a janela nunca mais esconde depois do
        // primeiro modo. Só limpa se ainda for ESTE agendamento.
        const liberar = () => {
          if (pendingSpeech === agendado) pendingSpeech = null;
          // Agora é a hora de esconder: o park de antes foi pulado de
          // propósito para não matar o quadro.
          if (!busy && !speaking && !stayQuiet) parkSoon();
        };
        agendado.then(liberar, liberar);
        agendado.catch(() => {});
      }
    } finally {
      busy = false;
      drainQueue();
      if (!busy && !stayQuiet) parkSoon();
    }
  }

  function nativeWindow(action) {
    try { nativeHandlers()?.jarvisWindow.postMessage(action); } catch { /* web */ }
  }

  function cancelPark() {
    window.clearTimeout(parkTimer);
    parkTimer = 0;
  }

  function compactReply() {
    const text = String(lastAnswer.textContent || "").replace(/\s+/g, " ").trim();
    if (!text) return "";
    return text.length > 80 ? `${text.slice(0, 77)}…` : text;
  }

  function holdReply() {
    const chip = compactReply();
    nativeWindow(chip ? `reply:${chip}` : "reply:");
  }

  function parkNow() {
    cancelPendingSpeech();
    cancelPark();
    holdReply();
    nativeWindow("hide");
  }

  function parkSoon() {
    cancelPark();
    if (!appMode || !ownerToken()) return;
    // Ensaio/filme: o JARVIS está sendo gravado e a janela é o palco. Sem
    // esta saída ela virava bolinha 8s depois de cada fala e o vídeo ficava
    // com um orbe de 72px no lugar do quadro.
    if (ensaioLigado) return;
    if (busy || speaking || meeting || stayQuiet) return;
    // Fala agendada (o quadro do modo Homem de Ferro chega em 9s): esconder
    // a janela cancela a fala, então o park espera ela terminar de acontecer.
    if (pendingSpeech) return;
    parkTimer = window.setTimeout(() => {
      if (busy || speaking || meeting || stayQuiet) return;
      // A fala agendada pode ter nascido depois deste timer: recheca aqui,
      // senão o park de 8s mata o quadro de 9s do modo.
      if (pendingSpeech) return;
      if (document.documentElement.classList.contains("needs-login")) return;
      if (document.activeElement === input) return;
      if (extras && !extras.hidden) return;
      parkNow();
    }, 8000);
  }

  function nativeListen(action) {
    try { nativeHandlers()?.jarvisListen.postMessage(action); } catch { /* web */ }
  }

  let armTimer = 0;
  function keepArmed() {
    armed = true;
    armUntil = Date.now() + 45_000;
    document.documentElement.classList.add("armed");
    orb.classList.add("listening");
    cancelPark();
    nativeWindow("touch");
    nativeListen("arm");
    window.clearTimeout(armTimer);
    armTimer = window.setTimeout(sleepUntilWake, 45_000);
  }

  function sleepUntilWake() {
    armed = false;
    armUntil = 0;
    window.clearTimeout(armTimer);
    pendingHeard = "";
    window.clearTimeout(heardTimer);
    orb.classList.remove("listening");
    document.documentElement.classList.remove("armed");
    paintHeard("");
    nativeListen("sleep");
    if (!busy && !speaking && !meeting) paintHome();
  }

  window.__jarvisNativeListen = function (state) {
    const raw = String(state || "");
    if (raw.startsWith("level:")) {
      if (!armed) return;
      const n = Number(raw.slice(6));
      const node = document.getElementById("heardLine");
      if (node && node.hidden && n > 0.008) {
        node.hidden = false;
        node.textContent = "mic ok";
      }
      return;
    }
    if (raw.startsWith("error:")) {
      const msg = raw.slice(6);
      if (/no speech|sem fala|1110|retry/i.test(msg)) return;
      paintHeard(msg);
      return;
    }
    if (raw === "waiting") {
      keepListening = true;
      if (armed) say("Ouvindo.", "Preparando fala no Mac…");
      listenPainted = false;
      return;
    }
    if (raw === "voice:down") {
      document.documentElement.classList.add("voice-down");
      return;
    }
    if (raw === "voice:ok") {
      document.documentElement.classList.remove("voice-down");
      return;
    }
    if (raw === "denied") {
      listenPainted = false;
      orb.classList.remove("listening");
      say("Mic.", "Ajustes → Privacidade → Microfone e Fala.");
      return;
    }
    if (raw === "listening" || raw === "waiting") {
      keepListening = true;
      listenPainted = true;
      // O soundbar também dança enquanto ele ouve: no vídeo a esfera com as
      // barras paradas parecia travada. `is-listening` reusa a mesma animação.
      const stage = document.getElementById("orbStage");
      if (stage) stage.classList.toggle("is-listening", raw === "listening");
      if (armed) {
        orb.classList.add("listening");
        say("Ouvindo.", "Pode falar.");
      }
    }
  };

  // Porta única para injetar fala: o modo ensaio usa esta.
  // No ensaio o JARVIS fica sempre armado: são minutos de gravação e o
  // `armed` cai sozinho em 45s, o que engolia as frases depois da metade.
  let ensaioLigado = false;
  window.__jarvisModoEnsaio = () => {
    // Desliga a escuta do navegador: no ensaio quem fala é o roteiro, e o
    // microfone do Chrome só servia para pintar "Toque no brilho" por cima.
    ensaioLigado = true;
    armed = true;
    armUntil = Date.now() + 6 * 60 * 60 * 1000;
    document.documentElement.classList.add("armed");
    window.clearTimeout(armTimer);
    const node = document.getElementById("caption");
    if (node) node.textContent = "Modo ensaio.";
    return true;
  };

  window.__jarvisDizer = (texto) => {
    if (!armed) window.__jarvisModoEnsaio();
    hearSpoken(String(texto || ""), true);
  };

  // A web do JARVIS na segunda tela é a mesma sessão, mas sem login: a
  // etiqueta "Visitante" aparecendo no vídeo entregaria que é só um site.
  // No ensaio ela vira o mesmo rótulo do app.
  window.__jarvisModoFilme = () => {
    window.__jarvisModoEnsaio();
    renderAccess("JARVIS · 3×", true);
    document.documentElement.classList.add("modo-filme");
    return true;
  };

  // Fala do JARVIS no roteiro do vídeo. Não passa pelo servidor: o dono quer
  // o vídeo agora, e o texto é dele. A ordem de cada passo é a mesma que a
  // resposta real do /command faz, menos o fetch.
  window.__jarvisNarra = async (texto) => {
    window.__jarvisModoEnsaio();
    const fala = String(texto || "").trim();
    if (!fala) return false;
    say("JARVIS", "senhor");
    await speak(fala);
    return true;
  };

  // Modo Homem de Ferro encenado: o Spotify abre pela primeira tela e o
  // quadro é lido aqui, sem Supabase, sem catálogo e sem modelo. Quando o
  // modo virar real, é este bloco que sai — o resto já é o caminho de
  // verdade.
  const ABERTURA_FERRO = "Entrando no modo Homem de Ferro.";
  // A hora é a do Mac na hora de gravar; o clima continua encenado.
  function horaFalada(agora) {
    const h = agora.getHours();
    const m = agora.getMinutes();
    const periodo = h < 6 ? "da madrugada" : h < 12 ? "da manhã" : h < 18 ? "da tarde" : "da noite";
    const h12 = h % 12 === 0 ? 12 : h % 12;
    const horas = h12 === 1 ? "é 1 hora" : `são ${h12} horas`;
    return `${horas}${m ? ` e ${m}` : ""} ${periodo}`;
  }
  function bomDiaFerro(agora = new Date()) {
    const h = agora.getHours();
    const saudacao = h < 12 ? "Bom dia" : h < 18 ? "Boa tarde" : "Boa noite";
    return `${saudacao}, senhor. Hoje o tempo está nublado, ${horaFalada(agora)}, 22 graus e perfeito para trabalhar. Quer que eu abra o modo web ou o modo fullscreen?`;
  }
  // A música toca sozinha este tempo antes de ele falar o bom dia.
  const ESPERA_MUSICA_FERRO_MS = 9000;

  window.__jarvisHomemDeFerro = async () => {
    window.__jarvisModoFilme();
    window.__jarvisSetIdle?.(false);
    document.documentElement.classList.add("modo-ferro");
    try { nativeWindow("show"); } catch (e) { /* web */ }
    // Pré-aquece o bom dia: a síntese leva ~2s por frase nova e a fala tem
    // que sair no segundo 9 da música, não no 11.
    const bomDia = bomDiaFerro();
    window.JarvisLocalVoice?.speakBlob?.(bomDia, { persona: "jarvis" })?.catch?.(() => {});
    await speak(ABERTURA_FERRO);
    // Back in Black vem de um mp3 local tocado pelo app, que mantém o volume
    // dele sempre abaixo da voz. Sem internet, sem Spotify.
    try { window.webkit?.messageHandlers?.jarvisMusic?.postMessage("play"); } catch (e) { /* web */ }
    await new Promise((resolve) => window.setTimeout(resolve, ESPERA_MUSICA_FERRO_MS));
    await speak(bomDia);
    // A oferta vale a partir da pergunta, não do "entra no modo".
    filme.ofertaWeb = true;
    filme.ofertaEm = Date.now();
    seguirRoteiroAuto();
    return true;
  };

  // "abre o fullscreen": a mesma segunda tela, em tela cheia. O app sai de
  // cima e o site ocupa tudo — é o palco do vídeo, mas quem abre é o app,
  // como sempre foi (o JARVIS não troca de cara, só mostra o site cheio).
  window.__jarvisFullscreen = async () => {
    window.__jarvisModoEnsaio();
    // O app se amplia sobre a própria tela (a 2) e fica ali: nada de abrir o
    // site no Chrome da TV. Sem fala — a tela crescendo já é a resposta.
    try {
      window.webkit?.messageHandlers?.jarvisFullscreen?.postMessage("on");
    } catch (e) { /* web */ }
    return true;
  };

  // O "sim" do dono no roteiro: a web é encenada. Em vez de abrir o site de
  // verdade, o MacBook (tela 2) mostra o clipe gravado do modo web em tela
  // cheia, e as cenas seguintes (agenda) abrem por cima dele.
  window.__jarvisAbrirWeb = async () => {
    window.__jarvisModoEnsaio();
    // Sem fullscreen a janela tem 268x380 e o clipe não cabe: ela cobre a
    // tela dela antes do vídeo entrar.
    try { window.webkit?.messageHandlers?.jarvisFullscreen?.postMessage("on"); } catch (e) { /* web */ }
    window.__jarvisAbrirSite?.("jarvis:modo-web");
    await speak("Abrindo, senhor.");
    return true;
  };

  // O projeto no GitHub abre na tela 1, a TV (~/.jarvis/telas.json), e o
  // JARVIS avisa onde: a tela central é a que o dono mostra no vídeo.
  window.__jarvisAbrirGithub = async () => {
    window.__jarvisModoEnsaio();
    try {
      window.webkit?.messageHandlers?.jarvisDisplay?.postMessage(
        JSON.stringify({ url: "https://github.com/theopadilha2009-hash/jarvis-agent-os", tela: "1" })
      );
    } catch (e) { /* web */ }
    await speak("Abrindo meu projeto na tela central.");
    return true;
  };

  // Agenda virtual dentro do JARVIS, com o que ele vai dizer no vídeo.
  // `scheduled_for` é o campo que desenharHud lê para marcar o dia: os
  // compromissos são montados em cima da data de hoje, não em datas fixas.
  function agendaDoVideo() {
    // Amanhã, sexta-feira e domingo (0 = domingo), como o JARVIS diz. Se o dia
    // já passou na semana, vale o da próxima: a agenda nunca mostra reunião no
    // passado.
    const diaDaSemana = (dow, h, m) => {
      const quando = new Date();
      quando.setDate(quando.getDate() + ((dow - quando.getDay() + 7) % 7));
      quando.setHours(h, m, 0, 0);
      return quando.toISOString();
    };
    const amanha = new Date();
    amanha.setDate(amanha.getDate() + 1);
    amanha.setHours(10, 0, 0, 0);
    return [
      { title: "Reunião · VAMOO-AI", scheduled_for: amanha.toISOString(), notes: "com o Ruan" },
      { title: "Revisão do SiteHunter", scheduled_for: diaDaSemana(5, 15, 0), notes: "fechar o escopo" },
      { title: "Call · cliente novo", scheduled_for: diaDaSemana(0, 11, 0), notes: "nome a confirmar" },
    ];
  }

  window.__jarvisAgendaVideo = async () => {
    window.__jarvisModoEnsaio();
    window.__jarvisSetIdle?.(false);
    hudItens = agendaDoVideo();
    // O mês do painel pode ter ficado em outro depois de navegar: a agenda
    // do vídeo é sempre a do mês corrente.
    hudMesRef = new Date();
    desenharHud();
    abrirHud();
    await speak("Você tem três reuniões marcadas para essa semana, senhor. Uma para amanhã, uma para sexta-feira e uma para domingo. Deseja confirmar ou saber qual é qual?");
    return true;
  };

  // Gatilhos do roteiro: valem nas duas pontas. Quando ninguém manda o
  // roteiro (o dono escrevendo na web), a fala também leva à cena — senão só
  // o arquivo gravado funcionaria e o resto continuava falando por cima.
  // Resposta afirmativa à oferta do JARVIS. Aceita o nome no fim ("sim,
  // Jarvis") porque é assim que o dono responde quando fala com o app.
  const RESPOSTA_ABRIR = /^\s*(?:sim|pode|pode abrir|pode ser|manda|manda ver|claro|bora|isso|beleza|vai|vamos)(?:[\s,!.]+(?:jarvis|senhor))?[\s.!]*$/i;

  const GATILHOS_FILME = [
    // Saídas primeiro: "fecha o fullscreen" também contém "fullscreen", e
    // "para a música" não pode cair em outra cena. Sem elas o mp3 e a tela
    // cheia ficavam sem como parar.
    { teste: /\b(?:para|pare|parar|fecha|fechar|desliga|desligar|tira|tirar|chega\s+de|silencia)\b.*\b(?:m[uú]sica|mp3|trilha|som)\b|\b(?:m[uú]sica|mp3|trilha)\b.*\b(?:para|pare|chega)\b/i, cena: "parar_musica" },
    { teste: /\b(?:para|pare|parar|cancela|cancelar|interrompe)\b.*\broteiro\b/i, cena: "parar_roteiro" },
    { teste: /\b(?:sai|sair|saia|fecha|fechar|desliga|desligar|tira|tirar|volta|voltar)\b.*\b(?:full\s*screen|tela\s+cheia)\b/i, cena: "sair_fullscreen" },
    // "abre o fullscreen" é a segunda tela em tela cheia; "abre a web" é o
    // site normal. São coisas diferentes e o dono pediu as duas.
    { teste: /\bfull\s*screen\b|\btela\s+cheia\b/i, cena: "fullscreen" },
    { teste: /\b(?:modo\s+)?homem[\s-]+de[\s-]+ferro\b|\bmodo\s+ferro\b|\biron[\s-]?man\b/i, cena: "ferro" },
    // O dono responde de vários jeitos ao "quer que eu abra a web?": "pode",
    // "pode abrir", "sim, Jarvis", "manda ver". Antes só quatro palavras
    // exatas passavam, e "pode abrir" caía no modelo em vez de abrir a tela.
    { teste: RESPOSTA_ABRIR, cena: "web", precisaFerro: true },
    // "modo web" como resposta ao "web ou fullscreen?". Ancorado e curto: o
    // dono diz "além do modo web que é gratuito" no pedido do GitHub, e isso
    // não pode abrir a web.
    // "pode abrir no web", "abre o modo web", "web".
    { teste: /^\s*(?:(?:pode|quero|vamos|bora)\s+)?(?:(?:abre|abrir|abra)\s+)?(?:(?:no|na|o|a|em)\s+)?(?:modo\s+)?web[\s,.!]*(?:jarvis|senhor)?[\s.!]*$/i, cena: "web", precisaFerro: true },
    // "prévia do próximo vídeo" é como o dono pede — o padrão antigo exigia
  // "prévia DO vídeo" e não casava com a palavra "próximo" no meio.
  { teste: /site\s*hunter|pr[eé]via\s+(?:d[eo]\s+)?(?:pr[oó]xim[oa]\s+)?v[ií]deo|pr[oó]xim[oa]\s+preview/i, cena: "sitehunter" },
    { teste: /\b(?:agenda|calend[aá]rio)\b/i, cena: "agenda" },
    { teste: /github|projeto\s+(?:no|do)\s+(?:git|github)/i, cena: "github" },
    // Resposta ao "Deseja confirmar?" da agenda: "não, agora não, obrigado".
    { teste: /\bn[aã]o\b.*\bobrigad[oa]\b|\bagora\s+n[aã]o\b/i, cena: "recusa" },
  ];

  // Estado do roteiro dentro da página. Sem ele, "sim" abriria a web em
  // qualquer momento — no vídeo ele só responde à pergunta do modo.
  const filme = { ferro: false, ofertaWeb: false, ofertaEm: 0 };

  // A oferta expira: microfone armado numa sala pode ouvir um "pode" solto
  // minutos depois, e ele não pode abrir a segunda tela do nada.
  function ofertaViva() {
    if (!filme.ofertaWeb) return false;
    return Date.now() - filme.ofertaEm < JANELA_RESPOSTA_CURTA_MS * 3;
  }

  function cenaDoRoteiro(value) {
    const pedido = String(value || "").trim();
    if (!pedido) return null;
    for (const gatilho of GATILHOS_FILME) {
      if (!gatilho.teste.test(pedido)) continue;
      // O "sim" só vale como resposta à oferta: fora do vídeo ele continua
      // indo pro servidor, como sempre foi.
      if (gatilho.precisaFerro && !ofertaViva()) continue;
      if (gatilho.cena === "ferro") {
        filme.ferro = true;
        filme.ofertaWeb = true;
        filme.ofertaEm = Date.now();
      }
      return {
        run: () => window.__jarvisRoteiro(gatilho.cena),
        speak: () => "",
      };
    }
    return null;
  }

  // Porta única do roteiro gravado no app: cada cena é uma função aqui.
  // Devolve a promessa da cena (ou null se o nome não existe) para o roteiro
  // automático esperar uma terminar antes de contar a espera da próxima.
  function iniciarCena(chave) {
    const cena = {
      ferro: window.__jarvisHomemDeFerro,
      web: window.__jarvisAbrirWeb,
      fullscreen: window.__jarvisFullscreen,
      github: window.__jarvisAbrirGithub,
      agenda: window.__jarvisAgendaVideo,
      sitehunter: window.__jarvisSiteHunter,
      recusa: window.__jarvisRecusa,
      parar_musica: () => {
        try { window.webkit?.messageHandlers?.jarvisMusic?.postMessage("stop"); } catch (e) { /* web */ }
        return speak("Música desligada.");
      },
      parar_roteiro: () => {
        rodadaAuto += 1;
        autoRodando = false;
        return Promise.resolve();
      },
      sair_fullscreen: () => {
        nativeWindow("fullscreen");
        return Promise.resolve();
      },
    }[chave];
    if (!cena) return null;
    window.__jarvisSonda?.(`cena: ${chave}`);
    // A mesma frase chega mais de uma vez (parcial e final do reconhecedor,
    // eco, retry do app): a cena em andamento, ou que acabou de rodar, não
    // roda de novo. Era o JARVIS repetindo a fala dele duas vezes.
    // O microfone ouve a voz do próprio JARVIS ("Entrando no modo Homem de
    // Ferro") e ela casava de novo com o gatilho: o modo recomeçava no meio,
    // com a música reiniciando e a pergunta repetida. Com o roteiro andando,
    // só "para o roteiro" o interrompe.
    if (chave === "ferro" && autoRodando) {
      window.__jarvisSonda?.("cena ferro ignorada: roteiro em andamento");
      return Promise.resolve();
    }
    const estado = (cenasRodando[chave] ||= { rodando: false, fim: 0 });
    if (estado.rodando || Date.now() - estado.fim < REPETIR_CENA_MS) {
      window.__jarvisSonda?.(`cena repetida ignorada: ${chave}`);
      return Promise.resolve();
    }
    estado.rodando = true;
    // Recomeçar o modo zera o que já foi feito e cancela o roteiro anterior.
    // A web é uma cena do automático (o clipe), então não o cancela.
    if (chave === "ferro") {
      rodadaAuto += 1;
      filme.feitas = new Set();
    }
    (filme.feitas ||= new Set()).add(chave);
    // A pergunta do modo Homem de Ferro morre quando a cena seguinte começa:
    // sem isto, o "modo web" do pedido do GitHub ainda contava como resposta.
    if (chave !== "ferro") filme.ofertaWeb = false;
    const terminou = () => { estado.rodando = false; estado.fim = Date.now(); };
    try {
      return Promise.resolve(cena()).catch(() => {}).finally(terminou);
    } catch (e) {
      terminou();
      return Promise.resolve();
    }
  }

  window.__jarvisRoteiro = (nome) => iniciarCena(String(nome || "").trim()) !== null;
  const cenasRodando = {};
  const REPETIR_CENA_MS = 4000;

  // Depois do "entra no modo Homem de Ferro" o resto roda sozinho, sem o app
  // ouvir nada: o dono fala por cima no vídeo e as telas abrem no tempo certo.
  // [espera antes da cena (ms), cena]. A espera conta do fim da cena anterior.
  const ROTEIRO_AUTO = [
    [8000, "web"],          // ele responde "web": o clipe toca no MacBook
    [12000, "github"],      // "abre seu projeto no GitHub..." (pedido de ~10 s)
    [12000, "agenda"],      // pausa em silêncio + "abre uma agenda virtual"
    [8000, "recusa"],       // "Não, agora não, obrigado"
    [8000, "sitehunter"],   // "dá uma prévia do próximo vídeo"
  ];
  let rodadaAuto = 0;
  let autoRodando = false;

  async function seguirRoteiroAuto() {
    const minha = ++rodadaAuto;
    autoRodando = true;
    for (const [espera, nome] of ROTEIRO_AUTO) {
      await new Promise((resolve) => window.setTimeout(resolve, espera));
      if (minha !== rodadaAuto) return;
      // O dono pode ter pedido a cena por voz antes do tempo.
      if (filme.feitas?.has(nome)) {
        window.__jarvisSonda?.(`roteiro auto: ${nome} já feita, pulando`);
        continue;
      }
      await iniciarCena(nome);
      if (minha !== rodadaAuto) return;
    }
    autoRodando = false;
  }

  // "Não, agora não, obrigado" depois do "Deseja confirmar?" da agenda.
  window.__jarvisRecusa = async () => {
    window.__jarvisModoEnsaio();
    await speak("Certo, senhor.");
    return true;
  };

  // Prévia do próximo vídeo: o print do SiteHunter abre sozinho na tela 3.
  const PREVIA_PROXIMO_VIDEO = "https://jarvis-theo.vercel.app/ui/filme/sitehunter.png";
  window.__jarvisSiteHunter = async () => {
    window.__jarvisModoEnsaio();
    fecharHud();
    // É a última cena: o clipe do modo web sai do MacBook e a imagem vai
    // sozinha para a tela 3 (HDMI).
    fecharSite();
    try {
      window.webkit?.messageHandlers?.jarvisDisplay?.postMessage(
        JSON.stringify({ url: PREVIA_PROXIMO_VIDEO, tela: "3" })
      );
    } catch (e) { /* web */ }
    await speak("A prévia do próximo vídeo, senhor.");
    return true;
  };

  // ---------- Modo ensaio (só para gravar o vídeo) ----------
  // O microfone deste Mac entrega áudio que o reconhecedor descarta, então
  // para o vídeo a fala é injetada direto. `ens = [["bom dia", 2.6], ...]`
  // dispara cada frase depois do intervalo dado, contado a partir da chamada.
  window.__jarvisEnsaio = function (roteiro) {
    const lista = Array.isArray(roteiro) ? roteiro : [];
    let atraso = 0;
    for (const item of lista) {
      const texto = String(item[0] || "");
      const espera = Number(item[1]) || 0;
      atraso += espera;
      window.setTimeout(() => {
        if (!texto) return;
        if (window.__jarvisSetIdle) window.__jarvisSetIdle(false);
        hearSpoken(texto, true);
      }, atraso);
    }
  };

  window.__jarvisNativeHeard = function (spoken, isFinal) {
    hearSpoken(spoken, isFinal !== false);
  };

  window.__jarvisSetIdle = function (on) {
    const idle = on === true || on === "true";
    const text = String(lastAnswer.textContent || "").replace(/\s+/g, " ").trim();
    if (idle && text) lastAnswer.hidden = false;
    document.documentElement.classList.toggle("idle-orb", idle);
    document.documentElement.classList.toggle("has-reply", idle && Boolean(text));
    if (idle) sleepUntilWake();
  };

  window.__jarvisOnActionResult = function(result) {
    if (!result) return;
    say("JARVIS", result);
    paintHeard(result);
    try {
      if (lastAnswer) {
        lastAnswer.textContent = result;
        lastAnswer.hidden = false;
      }
    } catch(e){}
  };

  document.querySelectorAll(".btn-chip").forEach(btn => {
    btn.addEventListener("click", () => {
      const act = btn.getAttribute("data-action");
      if (act) fireAsk(act);
    });
  });


  function foldSpeech(text) {
    return String(text || "")
      .toLocaleLowerCase("pt-BR")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/['"`´]/g, "")
      .replace(/[^a-z0-9\s]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function splitWake(text) {
    const folded = foldSpeech(text);
    if (!folded) return null;
    const hit = folded.match(WAKE_NAME);
    if (!hit || hit.index == null) return null;
    const after = folded.slice(hit.index + hit[0].length).replace(WAKE_CALL, " ").replace(/\s+/g, " ").trim();
    let before = folded.slice(0, hit.index).replace(WAKE_CALL, " ").replace(/\s+/g, " ").trim();
    if (WAKE_ONLY.test(before)) before = "";
    return { command: after || before, folded };
  }

  function paintHeard(text) {
    const node = document.getElementById("heardLine");
    if (!node) return;
    const clean = String(text || "").replace(/\s+/g, " ").trim();
    node.hidden = !clean;
    node.textContent = clean ? `ouvi: ${clean}` : "";
  }

  function takeWake(text, isFinal) {
    if (isQuietAsk(text)) {
      const hit = splitWake(text);
      if (!armed && !hit) return;
      if (!isFinal) return;
      stayQuiet = false;
      fireAsk(text);
      return;
    }
    const hit = splitWake(text);
    if (stayQuiet && !hit) return;
    if (hit) {
      stayQuiet = false;
      nativeWindow("touch");
      keepArmed();
      if (!hit.command) {
        say("Senhor.", "Pode falar.");
        return;
      }
      if (isRepeatAsk(hit.command)) {
        lastAsked = "";
        lastAskedAt = 0;
        if (lastCommand) fireAsk(lastCommand);
        return;
      }
      if (!isFinal) {
        say("Ouvindo.", hit.command);
        return;
      }
      fireAsk(hit.command);
      return;
    }
    if (armed && Date.now() <= armUntil) {
      // A cena do roteiro vem ANTES do filtro de comando: "pode abrir" é a
      // resposta à pergunta do JARVIS e não começa com verbo, então o
      // looksLikeCommand descartava a resposta e a web nunca abria.
      if (!looksLikeCommand(text) && !cenaDoRoteiro(text)) return;
      if (!isFinal) {
        say("Ouvindo.", text);
        return;
      }
      if (isRepeatAsk(text)) {
        lastAsked = "";
        lastAskedAt = 0;
        if (lastCommand) fireAsk(lastCommand);
        return;
      }
      keepArmed();
      fireAsk(text);
    }
  }

  function fireAsk(command) {
    const clip = String(command || "").replace(/\s+/g, " ").trim();
    if (!clip) return;
    const folded = foldSpeech(clip);
    // "desliga" é do app, não do Python: sem este filtro o processo abria e
    // o app fechava antes da faixa do modo Homem de Ferro entrar.
    const doApp = /^(?:acorda|acordar|acorde|volta|voltar)$/.test(folded)
      || /^(?:desliga|desligar)$|desliga(?:r)?(?:\s+o)?\s*jarvis\b|fechar?\s*(?:o)?\s*jarvis|encerrar?\s*(?:o)?\s*jarvis/i.test(folded)
      || /(?:vai|va)\s+dormir|^(?:dorme|durma|dormir)$/i.test(folded);
    try {
      if (!doApp && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.jarvisAction) {
        window.webkit.messageHandlers.jarvisAction.postMessage(clip);
      }
    } catch(e){}
    // Acordar: volta a ouvir sem reabrir nada.
    if (/^(?:acorda|acordar|acorde|volta|voltar)$/i.test(folded)) {
      say("Acordado.", "Pode falar.");
      keepArmed();
      if (!stayQuiet) speak("Pode falar, senhor.");
      return;
    }
    // Desligar de verdade: verbo explícito de fechar/encerrar.
    if (/^(?:desliga|desligar)$|desliga(?:r)?(?:\s+o)?\s*jarvis\b|fechar?\s*(?:o)?\s*jarvis|encerrar?\s*(?:o)?\s*jarvis/i.test(folded)) {
      say("Desligando.", "Até logo, senhor.");
      speak("Até logo, senhor. Desligando.");
      window.setTimeout(() => nativeWindow("shutdown"), 1800);
      return;
    }
    // Dormir: para de ouvir e fica quieto — NÃO fecha o app. Antes "dorme"
    // caía no mesmo ramo do desligar e fechava o JARVIS.
    if (/(?:vai|va)\s+dormir|^(?:dorme|durma|dormir)$/i.test(folded)) {
      say("Dormindo.", 'Chame "Jarvis, acorda" quando precisar.');
      if (!stayQuiet) speak("Dormindo, senhor.");
      sleepUntilWake();
      return;
    }

    if (folded === foldSpeech(lastAsked) && Date.now() - lastAskedAt < 4000) return;
    if (isLookAsk(clip)) {
      lastAsked = clip;
      lastAskedAt = Date.now();
      seeScreen(clip);
      return;
    }
    const items = expandCommands(clip);
    lastAsked = items[0];
    lastAskedAt = Date.now();
    for (let index = 1; index < items.length; index += 1) enqueue(items[index]);
    ask(items[0]);
  }

  function isRepeatAsk(text) {
    return /^(?:repete|repete isso|de novo|outra vez|diz de novo|fala de novo|repete o ultimo)$/.test(foldSpeech(text));
  }

  function spokenReply(text) {
    const clip = String(text || "").replace(/\s+/g, " ").trim();
    if (!clip) return "";
    // Até 2 frases: falar só a primeira dava a impressão de cortar no meio.
    const parts = clip.match(/[^.!?…]+[.!?…]*\s*/g) || [clip];
    const spoken = parts.slice(0, 2).join("").trim();
    return spoken.slice(0, 300).trim();
  }

  function hearSpoken(spoken, isFinal = true) {
    const text = String(spoken || "").trim();
    if (!text) return;
    // Vai para /tmp/jarvis-listen.log: sem isto não dá para saber o que o
    // reconhecedor entendeu quando "ele não escuta".
    try { nativeHandlers()?.jarvisSonda.postMessage("ouvi: " + text.slice(0, 120)); } catch { /* web */ }
    // Eco da própria voz não é comando do dono, nem com o nome dele no meio.
    if (ecoDaPropriaFala(text)) return;
    const woke = Boolean(splitWake(text));
    if (!armed && !woke && !(isQuietAsk(text) && armed)) return;
    if (armed || woke) paintHeard(text);
    if (speaking) {
      const hit = splitWake(text);
      // Falar por cima do JARVIS já interrompe — mas só se a fala nova for
      // um pedido. A resposta curta ao "quer que eu abra a web?" era tratada
      // como interrupção atrás da palavra "Jarvis": o dono respondia "pode
      // abrir" enquanto o quadro ainda falava e a resposta era descartada.
      const aceita = hit || cenaDoRoteiro(text) || (isQuietAsk(text) && armed);
      if (!aceita) return;
      stopSpeak();
      cancelPendingSpeech();
      try { nativeHandlers()?.jarvisListen.postMessage("resume"); } catch { /* web */ }
      takeWake(text, isFinal);
      return;
    }
    if (isQuietAsk(text) && (armed || splitWake(text))) {
      takeWake(text, isFinal);
      return;
    }
    if (!isFinal) {
      pendingHeard = text;
      window.clearTimeout(heardTimer);
      takeWake(text, false);
      // 550ms cortava quem respira depois do nome. Pausa depois de "Jarvis,"
      // é natural e ganha mais folga; frase em andamento ganha 1,4s.
      const justWake = new RegExp("^\\s*(?:" + WAKE_ALT + ")\\s*[,.]?\\s*$", "i").test(text);
      heardTimer = window.setTimeout(
        () => hearSpoken(pendingHeard, true),
        justWake ? 1800 : 1400,
      );
      return;
    }
    window.clearTimeout(heardTimer);
    pendingHeard = "";
    takeWake(text, true);
  }

  function listenLoop() {
    if (!keepListening || speaking) return;
    if (hasNativeListen()) {
      nativeListen(armed ? "arm" : "start");
      if (armed) {
        orb.classList.add("listening");
        say("Ouvindo.", "Pode falar.");
      }
      return;
    }
    if (!Recognition) return;
    const rec = new Recognition();
    recHandle = rec;
    rec.lang = "pt-BR";
    rec.continuous = true;
    rec.interimResults = true;
    rec.onresult = (event) => {
      const last = event.results?.[event.results.length - 1];
      hearSpoken(last?.[0]?.transcript || "", Boolean(last?.isFinal));
    };
    rec.onerror = (event) => {
      if (event.error === "not-allowed") {
        keepListening = false;
        recHandle = null;
        orb.classList.remove("listening");
        say("Mic.", "Toque no brilho e permita.");
        return;
      }
      if (keepListening && !speaking) window.setTimeout(listenLoop, 500);
    };
    rec.onend = () => {
      if (recHandle === rec) recHandle = null;
      if (keepListening && !speaking) window.setTimeout(listenLoop, 180);
    };
    try {
      rec.start();
      if (armed) {
        orb.classList.add("listening");
        say("Ouvindo.", "Pode falar.");
      }
    } catch {
      if (keepListening && !speaking) window.setTimeout(listenLoop, 600);
    }
  }

  function persistListen(on) {
    try {
      if (on) window.localStorage.setItem(LISTEN_KEY, "1");
      else window.localStorage.setItem(LISTEN_KEY, "0");
    } catch { /* private */ }
  }

  function wantsListen() {
    // Só o app nativo escuta. A aba do navegador é a MESMA sessão do JARVIS
    // na segunda tela: se ela também abrisse o microfone, os dois ouviriam a
    // mesma frase e responderiam juntos. Aqui ela só mostra e fala.
    if (!hasNativeListen()) return false;
    if (appMode) return true;
    try {
      const stored = window.localStorage.getItem(LISTEN_KEY);
      if (stored === "0") return false;
      return stored === "1";
    } catch {
      return false;
    }
  }

  function startWebBackup() {
    if (hasNativeListen()) return;
    if (!Recognition) return;
    try { recHandle && recHandle.stop(); } catch { /* already stopped */ }
    const rec = new Recognition();
    recHandle = rec;
    rec.lang = "pt-BR";
    rec.continuous = true;
    rec.interimResults = true;
    rec.onresult = (event) => {
      const last = event.results?.[event.results.length - 1];
      hearSpoken(last?.[0]?.transcript || "", Boolean(last?.isFinal));
    };
    rec.onerror = () => {};
    rec.onend = () => {
      if (recHandle === rec) recHandle = null;
      if (keepListening && !speaking) window.setTimeout(startWebBackup, 250);
    };
    try { rec.start(); } catch { /* native segue */ }
  }

  function forceListen() {
    cancelPark();
    speaking = false;
    stayQuiet = false;
    meeting = false;
    document.documentElement.classList.remove("meeting");
    keepListening = false;
    listenPainted = false;
    window.clearTimeout(heardTimer);
    pendingHeard = "";
    nativeListen("restart");
    nativeWindow("touch");
    startWakeLoop({ force: true });
    startWebBackup();
  }

  function startWakeLoop(options) {
    const silent = Boolean(options && options.silent);
    const force = Boolean(options && options.force);
    if (!Recognition && !hasNativeListen()) {
      if (!silent) {
        input.focus();
        say("Escreva.", "Sem microfone aqui.");
      }
      return;
    }
    if (keepListening && !force) return;
    keepListening = true;
    persistListen(true);
    if (force) keepArmed();
    else sleepUntilWake();
    listenLoop();
  }

  function stopWakeLoop() {
    keepListening = false;
    armed = false;
    persistListen(false);
    orb.classList.remove("listening");
    say("Parei.", "Toque no brilho para ouvir de novo.");
  }

  function tryAutoListen() {
    const kick = () => {
      if (ensaioLigado) return;
      if (!wantsListen() || speaking) return;
      if (!keepListening) startWakeLoop({ silent: true });
      else if (hasNativeListen()) {
        try { nativeHandlers().jarvisListen.postMessage("start"); } catch { /* web */ }
      }
    };
    kick();
    window.setInterval(kick, 4000);
    document.addEventListener("visibilitychange", () => { if (!document.hidden) kick(); });
    if (!Recognition || hasNativeListen()) return;
    const permissions = navigator.permissions;
    if (permissions && permissions.query) {
      Promise.resolve(permissions.query({ name: "microphone" })).then((status) => {
        if (status.state === "denied") {
          say("Mic.", "Ajustes → Privacidade → Microfone.");
          return;
        }
        status.onchange = () => { if (status.state === "granted") kick(); };
      }).catch(() => {});
    }
  }

  moreButton.addEventListener("click", () => {
    cancelPark();
    nativeWindow("touch");
    extras.hidden = !extras.hidden;
    moreButton.textContent = extras.hidden ? "mais" : "fechar";
  });
  document.getElementById("loginToggle")?.addEventListener("click", () => {
    nativeWindow("focus");
    revealLogin();
  });
  document.getElementById("retryButton")?.addEventListener("click", () => {
    if (lastCommand) ask(lastCommand);
  });
  document.getElementById("debugToggle")?.addEventListener("click", () => {
    mountDebug(true);
  });
  document.getElementById("reloadButton")?.addEventListener("click", restartForUpdate);
  document.getElementById("meetingButton")?.addEventListener("click", toggleMeeting);
  const minimizeButton = document.getElementById("minimizeButton");
  if (minimizeButton) {
    minimizeButton.hidden = !hasNativeListen();
    minimizeButton.addEventListener("click", () => parkNow());
  }
  const btnMacClose = document.getElementById("btnMacClose");
  if (btnMacClose) {
    btnMacClose.addEventListener("click", (e) => {
      e.stopPropagation();
      nativeWindow("shutdown");
    });
  }
  const btnMacMin = document.getElementById("btnMacMin");
  if (btnMacMin) {
    btnMacMin.addEventListener("click", (e) => {
      e.stopPropagation();
      nativeWindow("minimize");
      if (window.__jarvisSetIdle) window.__jarvisSetIdle(true);
    });
  }
  const btnMacZoom = document.getElementById("btnMacZoom");
  if (btnMacZoom) {
    btnMacZoom.addEventListener("click", (e) => {
      e.stopPropagation();
      nativeWindow("zoom");
      extras.hidden = !extras.hidden;
      moreButton.textContent = extras.hidden ? "mais" : "fechar";
    });
  }
  function toggleMeeting() {
    meeting = !meeting;
    document.documentElement.classList.toggle("meeting", meeting);
    if (meeting) {
      stayQuiet = true;
      armed = false;
      try { nativeHandlers()?.jarvisListen.postMessage("pause"); } catch { /* web */ }
      say("Reunião.", "Mic off. Em mais, reunião de novo.");
      return;
    }
    stayQuiet = false;
    forceListen();
  }

  orb.addEventListener("click", () => {
    window.clearTimeout(clickWait);
    clickWait = window.setTimeout(() => {
      if (document.documentElement.classList.contains("idle-orb")) {
        nativeWindow("focus");
        return;
      }
      forceListen(); // user-gesture
    }, 280);
  });
  orb.addEventListener("dblclick", (event) => {
    event.preventDefault();
    window.clearTimeout(clickWait);
    parkNow();
  });
  lastAnswer.addEventListener("click", () => {
    if (document.documentElement.classList.contains("idle-orb")) nativeWindow("focus");
  });
  input.addEventListener("focus", () => {
    cancelPark();
    nativeWindow("touch");
  });
  input.addEventListener("input", () => {
    cancelPark();
    nativeWindow("touch");
  });
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    startWakeLoop();
    const value = input.value;
    input.value = "";
    ask(value);
  });
  loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const username = document.getElementById("loginUser").value.trim();
    const password = document.getElementById("loginPass").value;
    if (!username || !password) {
      say("Login.", "Mesma conta do cockpit.");
      return;
    }
    try {
      const response = await fetch("/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = await response.json();
      if (!response.ok || !data.session_token) {
        say("Não.", data.error || "Login inválido.");
        flashLoginError();
        return;
      }
      const keep = document.getElementById("rememberLogin");
      try { localStorage.setItem(REMEMBER_KEY, keep && !keep.checked ? "0" : "1"); } catch { /* ignore */ }
      persistSession(data.session_token, username);
      nativeWindow("touch");
      document.getElementById("loginPass").value = "";
      extras.hidden = true;
      moreButton.textContent = "mais";
      await refreshAccess();
      startWakeLoop();
      // Sem isso a janela pode estar em modo compacto e parecer vazia logo
      // depois do login.
      if (window.__jarvisSetIdle) window.__jarvisSetIdle(false);
      say("JARVIS · 3×", "Diga Jarvis. Arraste e peça analisa isso.");
    } catch {
      say("Rede.", "Tente o login de novo.");
      flashLoginError();
    }
  });

  function flashLoginError() {
    if (!loginForm) return;
    loginForm.classList.remove("login-error");
    // Reflow força a animação a reiniciar quando o erro repete.
    void loginForm.offsetWidth;
    loginForm.classList.add("login-error");
    document.getElementById("loginPass").value = "";
    document.getElementById("loginPass").focus();
    window.setTimeout(() => loginForm.classList.remove("login-error"), 1000);
  }
  logoutButton.addEventListener("click", () => {
    localStorage.removeItem(OWNER_TOKEN_KEY);
    refreshAccess();
    say("Saiu.", "Visitante.");
  });
  document.querySelectorAll("[data-open]").forEach((button) => {
    button.addEventListener("click", () => {
      startWakeLoop();
      openTarget(button.getAttribute("data-open"));
    });
  });

  window.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeDebug();
      extras.hidden = true;
      moreButton.textContent = "mais";
    }
    if (event.key === "/" && document.activeElement !== input && document.activeElement?.tagName !== "INPUT") {
      event.preventDefault();
      input.focus();
    }
  });
  window.addEventListener("offline", () => say("Offline.", "Atalhos locais ainda funcionam."));
  window.addEventListener("online", () => say("Online.", "Pode pedir de novo."));
  try {
    const remembered = localStorage.getItem(LAST_LOGIN_KEY);
    const user = document.getElementById("loginUser");
    if (remembered && user) user.value = remembered;
    const keep = document.getElementById("rememberLogin");
    if (keep) keep.checked = rememberLoginEnabled();
  } catch { /* first visit */ }
  paintHome();
  refreshAccess();
  refreshVoiceChip();
  watchShellVersion();
  instalarHud();
  instalarSite();
  window.setInterval(refreshVoiceChip, 8000);
  tryAutoListen();
  window.setTimeout(() => document.documentElement.classList.remove("booting"), 650);
  if (/[?&]debug=1(?:&|$)/.test(location.search)) mountDebug(false);

  function restartForUpdate() {
    const url = new URL(location.href);
    url.searchParams.set("r", Date.now().toString(36));
    // O fala.js é servido com max-age de 1 ano e immutable: recarregar com
    // ?r= traz o MESMO arquivo do cache e o aviso nunca some. Aqui limpamos
    // o cache do app e os service workers antes de recarregar.
    const recarregar = () => {
      try {
        const native = nativeHandlers() && nativeHandlers().jarvisRestart;
        if (native) {
          native.postMessage("now");
          window.setTimeout(() => location.replace(url.href), 500);
          return;
        }
      } catch { /* web */ }
      location.replace(url.href);
    };
    const limpar = async () => {
      try {
        if (window.caches?.keys) {
          const nomes = await window.caches.keys();
          await Promise.all(nomes.map((n) => window.caches.delete(n)));
        }
      } catch { /* sem cache */ }
      try {
        const regs = await navigator.serviceWorker?.getRegistrations?.() || [];
        await Promise.all(regs.map((r) => r.unregister()));
      } catch { /* sem sw */ }
      recarregar();
    };
    limpar();
  }

  function paintShellVersion(live) {
    const localLabel = `v${SHELL_VERSION}`;
    const stale = Boolean(live && live !== SHELL_VERSION);
    const line = document.getElementById("buildLine");
    if (line) {
      line.textContent = stale ? `${localLabel} · desatualizada` : localLabel;
      line.dataset.state = stale ? "stale" : "current";
      line.hidden = false;
    }
    const toast = document.getElementById("updateToast");
    if (!toast) return;
    toast.hidden = !stale;
    // Em cima do orb um aviso fixo atrapalha: depois de um tempo ele recua
    // para uma pílula discreta e volta se houver atualização nova.
    if (stale && !toast.dataset.recuo) {
      toast.dataset.recuo = "1";
      window.setTimeout(() => toast.classList.add("recuando"), 6000);
    }
    if (!stale) {
      toast.classList.remove("recuando");
      delete toast.dataset.recuo;
    }
    const versions = document.getElementById("updateToastVersions");
    if (versions && stale) versions.textContent = `você ${localLabel} · no ar v${live}`;
  }

  async function checkShellVersion() {
    try {
      const response = await fetch("/status", { headers: apiHeaders() });
      const data = await response.json().catch(() => ({}));
      noteStatus(data);
      paintShellVersion(data?.shell?.overlay || data?.shell?.version || "");
    } catch {
      paintShellVersion("");
    }
  }

  // ---------- Painel holográfico da agenda ----------
  // O dono pediu a agenda DENTRO do JARVIS: uma projeção que abre sobre o
  // orbe, com calendário de verdade. Página separada ele recusou.
  const MESES_HUD = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
  let hudAberto = false;
  let hudMesRef = new Date();
  let hudItens = [];

  function hudElementos() {
    const painel = document.getElementById("hudAgenda");
    if (!painel) return null;
    return {
      painel,
      mes: document.getElementById("hudMes"),
      grade: document.getElementById("hudGrade"),
      vazio: document.getElementById("hudVazio"),
      anterior: document.getElementById("hudAnterior"),
      proximo: document.getElementById("hudProximo"),
      fechar: document.getElementById("hudFechar"),
    };
  }

  function chaveDoDia(data) {
    return `${data.getFullYear()}-${String(data.getMonth() + 1).padStart(2, "0")}-${String(data.getDate()).padStart(2, "0")}`;
  }

  function desenharHud() {
    const el = hudElementos();
    if (!el) return;
    const ano = hudMesRef.getFullYear();
    const mes = hudMesRef.getMonth();
    el.mes.textContent = `${MESES_HUD[mes]} ${ano}`;

    // Agrupa os compromissos por dia, para marcar o ponto no calendário.
    const porDia = new Map();
    for (const item of hudItens) {
      const bruto = item?.scheduled_for;
      if (!bruto) continue;
      const quando = new Date(bruto);
      if (Number.isNaN(quando.getTime())) continue;
      const chave = chaveDoDia(quando);
      const entrada = porDia.get(chave) || { total: 0, atraso: false };
      entrada.total += 1;
      if (quando < new Date()) entrada.atraso = true;
      porDia.set(chave, entrada);
    }

    const primeiro = new Date(ano, mes, 1);
    const inicio = new Date(primeiro);
    inicio.setDate(1 - primeiro.getDay());
    const hojeChave = chaveDoDia(new Date());
    const hojeMes = new Date();
    const esteMes = hojeMes.getFullYear() === ano && hojeMes.getMonth() === mes;

    el.grade.innerHTML = "";
    let noMes = 0;
    for (let i = 0; i < 42; i += 1) {
      const dia = new Date(inicio);
      dia.setDate(inicio.getDate() + i);
      const chave = chaveDoDia(dia);
      const doMes = dia.getMonth() === mes;
      const marca = porDia.get(chave);
      const celula = document.createElement("span");
      celula.className = "hud-dia";
      celula.textContent = String(dia.getDate());
      if (!doMes) celula.classList.add("fora");
      if (chave === hojeChave) celula.classList.add("hoje");
      if (marca) {
        celula.classList.add("tem");
        if (marca.atraso) celula.classList.add("atraso");
        celula.title = `${marca.total} compromisso${marca.total > 1 ? "s" : ""}`;
      }
      if (doMes) noMes += marca ? marca.total : 0;
      el.grade.appendChild(celula);
    }
    el.vazio.hidden = Boolean(noMes) || !esteMes;
    if (!noMes) {
      el.vazio.hidden = false;
      el.vazio.textContent = "Nada marcado neste mês.";
    }
  }

  async function carregarHud() {
    const el = hudElementos();
    if (!el) return;
    const cabecalhos = { "Accept": "application/json" };
    const token = ownerToken();
    if (token) cabecalhos["X-Jarvis-Owner-Token"] = token;
    try {
      const resposta = await fetch("/agenda", { headers: cabecalhos });
      const dados = await resposta.json().catch(() => ({}));
      hudItens = Array.isArray(dados?.agenda) ? dados.agenda : [];
    } catch {
      hudItens = [];
    }
    desenharHud();
  }

  function abrirHud() {
    const el = hudElementos();
    if (!el || hudAberto) return;
    hudAberto = true;
    // O painel é conteúdo: a janela precisa sair do modo bolinha para
    // mostrá-lo, senão ele abre atrás de um orbe de 72px.
    if (window.webkit?.messageHandlers?.jarvisWindow) {
      try { window.webkit.messageHandlers.jarvisWindow.postMessage("show"); } catch (e) { /* web */ }
    }
    el.painel.hidden = false;
    // Um quadro depois de sair do hidden: a transição precisa do estado inicial.
    requestAnimationFrame(() => el.painel.classList.add("aberto"));
    // Sem rede (vídeo, ida ao servidor falha) a lista não pode ser zerada:
    // era o que apagava a agenda encenada logo depois de ela aparecer.
    if (Array.isArray(hudItens) && hudItens.length) return;
    carregarHud();
  }

  function fecharHud() {
    const el = hudElementos();
    if (!el || !hudAberto) return;
    hudAberto = false;
    el.painel.classList.remove("aberto");
    window.setTimeout(() => {
      if (!hudAberto) el.painel.hidden = true;
    }, 280);
  }

  // ---------- Projeção de site dentro do JARVIS ----------
  // O dono pediu para o vídeo: quando ele manda abrir um site, o site surge
  // DENTRO do JARVIS, quase em tela cheia — não uma aba nova. Só a agenda e
  // o Spotify continuam indo para fora, porque são apps de verdade.
  // Só o SiteHunter é projetado dentro do JARVIS: é o vídeo dele. O GitHub
  // abre na terceira tela, como o dono montou o arranjo.
  // A cena: a animação sai do meio da tela e, atrás dela, entra o print do
  // produto. É a prévia do próximo vídeo, não um site — por isso nada de
  // iframe nem de carregar a página de verdade.
  const SITES_PROJETADOS = [
    {
      teste: /sitehunter/i,
      url: "https://sitehunter-ai-tau.vercel.app",
      nome: "SiteHunter",
      print: "/ui/filme/sitehunter.png",
      abertura: "/ui/filme/sitehunter-intro.svg",
    },
    // O "modo web" do vídeo: um clipe gravado, não o site de verdade.
    {
      teste: /^jarvis:modo-web$/,
      url: "jarvis:modo-web",
      nome: "JARVIS · Web",
      video: "/ui/filme/modo-web.mp4",
    },
  ];

  function siteProjetado(url) {
    const alvo = String(url || "");
    if (!alvo) return null;
    return SITES_PROJETADOS.find((s) => s.teste.test(alvo)) || null;
  }

  let siteAberto = null;

  function abrirSite(site) {
    const painel = document.getElementById("hudSite");
    const quadro = document.getElementById("hudSiteQuadro");
    const filme = document.getElementById("hudSiteFilme");
    const print = document.getElementById("hudSitePrint");
    const intro = document.getElementById("hudSiteIntro");
    const nome = document.getElementById("hudSiteNome");
    if (!painel) return false;
    const clipe = document.getElementById("hudSiteVideo");
    if (nome) nome.textContent = site.nome;
    if (clipe && !site.video) { clipe.pause(); clipe.hidden = true; }
    if (site.video && clipe) {
      // Clipe do modo web: toca mudo e em laço por baixo da agenda.
      if (quadro) { quadro.hidden = true; quadro.src = "about:blank"; }
      if (print) print.hidden = true;
      if (intro) intro.hidden = true;
      if (filme) filme.hidden = false;
      if (!clipe.getAttribute("src")) clipe.src = site.video;
      clipe.hidden = false;
      clipe.currentTime = 0;
      clipe.play().catch(() => {});
      painel.classList.remove("reproduzindo");
      painel.hidden = false;
      requestAnimationFrame(() => painel.classList.add("aberto"));
      siteAberto = site.url;
      return true;
    }
    if (site.print) {
      if (clipe) clipe.hidden = true;
      // Cena de prévia: a animação salta do centro e o print do produto
      // aparece atrás dela. Reanima do zero a cada pedido — o dono pode
      // repetir a fala no vídeo quantas vezes quiser.
      if (quadro) { quadro.hidden = true; quadro.src = "about:blank"; }
      if (filme) filme.hidden = false;
      if (print) { print.src = site.print; print.hidden = false; }
      if (intro) { intro.src = site.abertura || ""; intro.hidden = false; }
      painel.classList.remove("reproduzindo");
      void painel.offsetWidth;
      painel.hidden = false;
      requestAnimationFrame(() => painel.classList.add("aberto", "reproduzindo"));
      siteAberto = site.url;
      return true;
    }
    if (!quadro) return false;
    if (filme) filme.hidden = true;
    if (siteAberto !== site.url) {
      quadro.src = site.url;
      siteAberto = site.url;
    }
    painel.hidden = false;
    requestAnimationFrame(() => painel.classList.add("aberto"));
    return true;
  }

  function fecharSite() {
    const painel = document.getElementById("hudSite");
    if (!painel) return;
    painel.classList.remove("aberto", "reproduzindo");
    window.setTimeout(() => {
      painel.hidden = true;
      const quadro = document.getElementById("hudSiteQuadro");
      if (quadro) quadro.src = "about:blank";
      siteAberto = null;
    }, 300);
  }

  function instalarSite() {
    const fechar = document.getElementById("hudSiteFechar");
    if (fechar) fechar.addEventListener("click", fecharSite);
    window.__jarvisAbrirSite = (url) => {
      const site = siteProjetado(url);
      return site ? abrirSite(site) : false;
    };
  }

  function instalarHud() {
    const el = hudElementos();
    if (!el) return;
    el.fechar?.addEventListener("click", fecharHud);
    el.anterior?.addEventListener("click", () => {
      hudMesRef.setMonth(hudMesRef.getMonth() - 1);
      desenharHud();
    });
    el.proximo?.addEventListener("click", () => {
      hudMesRef.setMonth(hudMesRef.getMonth() + 1);
      desenharHud();
    });
    document.addEventListener("keydown", (evento) => {
      if (evento.key === "Escape" && hudAberto) fecharHud();
    });
  }

  function watchShellVersion() {
    paintShellVersion("");
    checkShellVersion();
    window.setInterval(checkShellVersion, 60 * 1000);
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) checkShellVersion();
    });
    document.getElementById("updateReloadButton")?.addEventListener("click", restartForUpdate);
  }

  function refreshVoiceChip() {
    const chip = document.getElementById("voiceChip");
    if (!chip || !window.JarvisLocalVoice?.probe) {
      voiceLocalOk = false;
      return;
    }
    Promise.resolve(window.JarvisLocalVoice.probe()).then(() => {
      voiceLocalOk = true;
      chip.hidden = false;
      chip.textContent = hasNativeSpeak() ? "voz JARVIS" : "voz local";
      chip.dataset.state = "local";
    }).catch(() => {
      voiceLocalOk = false;
      chip.hidden = false;
      chip.textContent = hasNativeSpeak() ? "voz JARVIS" : "voz local";
      chip.dataset.state = "local";
    });
  }

  function closeDebug() {
    const panel = document.getElementById("jarvisDebug");
    if (panel) panel.remove();
    window.clearInterval(debugTimer);
    debugTimer = 0;
  }

  function debugSet(id, text, state) {
    const node = document.getElementById(id);
    if (!node) return;
    node.textContent = text;
    if (state) node.dataset.state = state;
    else delete node.dataset.state;
  }

  function debugGatewayText() {
    if (!lastStatus) return "sem resposta";
    const mode = lastStatus.access?.mode;
    if (mode === "owner" || mode === "member") {
      return lastStatus.power_profile?.mode === "jarvis_3x" ? "conectado · 3×" : `conectado · ${mode}`;
    }
    return "respondeu, sem acesso";
  }

  function debugGatewayState() {
    return lastStatus && (lastStatus.access?.mode === "owner" || lastStatus.access?.mode === "member") ? "ok" : "bad";
  }

  function debugVoiceText() {
    if (hasNativeSpeak()) return "voz JARVIS do app";
    if (voiceLocalOk) {
      const info = window.JarvisLocalVoice?.info?.() || {};
      return info.engine ? `Pocket · ${info.engine}` : "Pocket ativa";
    }
    return "indisponível — fala cai pro navegador";
  }

  function debugVoiceState() {
    return hasNativeSpeak() || voiceLocalOk ? "ok" : "bad";
  }

  function micPermissionText() {
    if (micPermission === "granted") return "permitido";
    if (micPermission === "denied") return "bloqueado";
    if (micPermission === "prompt") return "pedir ao usar";
    if (micPermission) return micPermission;
    return hasNativeListen() ? "pelo app" : "desconhecido";
  }

  function probeMicPermission() {
    const permissions = navigator.permissions;
    if (!permissions?.query) {
      micPermission = "";
      return;
    }
    Promise.resolve(permissions.query({ name: "microphone" })).then((status) => {
      const update = () => { micPermission = status.state; };
      update();
      status.onchange = update;
    }).catch(() => {
      micPermission = "";
    });
  }

  function buildDebugText() {
    const tts = window.JarvisLocalVoice?.info?.() || {};
    return [
      `JARVIS diagnóstico · shell ${SHELL_VERSION}`,
      `quando ${new Date().toLocaleString("pt-BR")}`,
      `modo ${appMode ? "app (Mac)" : "web"}`,
      `gateway ${debugGatewayText()}`,
      `voz ${debugVoiceText()}`,
      `microfone ${micPermissionText()}`,
      `escuta automática ${keepListening ? "ligada" : "desligada"}`,
      `modo quieto ${stayQuiet ? "ligado" : "desligado"}`,
      `volume web ${Math.round(webVolume() * 100)}%`,
      `último comando ${lastCommand || "—"}`,
      `último erro ${lastError || "—"}`,
      `token ${ownerToken() ? "sim" : "não"}`,
      `login lembrado ${rememberLoginEnabled() ? "sim" : "não"}`,
      `persona ${document.documentElement.dataset.persona || "—"}`,
      `tts ${tts.ok ? `${tts.engine || "ok"} ${tts.voice || ""}`.trim() : "offline"}`,
      `último ouvido ${document.getElementById("heardLine")?.textContent || "—"}`,
    ].join("\n");
  }

  function copyDebug() {
    const text = buildDebugText();
    if (navigator.clipboard?.writeText) {
      navigator.clipboard.writeText(text).then(
        () => say("Copiado.", "Diagnóstico na área de transferência."),
        () => say("Copiar.", "Não consegui copiar."),
      );
      return;
    }
    say("Copiar.", "Sem área de transferência aqui.");
  }

  function mountDebug(fromButton) {
    if (document.getElementById("jarvisDebug")) {
      closeDebug();
      return;
    }
    const panel = document.createElement("div");
    panel.id = "jarvisDebug";
    panel.className = "debug-panel";
    panel.setAttribute("role", "region");
    panel.setAttribute("aria-label", "Diagnóstico do JARVIS");
    panel.innerHTML = [
      '<header class="debug-head">',
      '<strong>diagnóstico</strong>',
      '<button id="debugClose" class="btn debug-close" type="button" aria-label="Fechar diagnóstico">',
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>',
      "</button>",
      "</header>",
      '<p class="debug-note" id="debugVoiceDown" hidden>voz local indisponível — fala cai pro navegador</p>',
      '<div class="debug-block" aria-label="Estado">',
      '<p class="debug-title">estado</p>',
      '<div class="debug-row"><span class="debug-label">gateway</span><span class="debug-value" id="debugGateway">consultando…</span></div>',
      '<div class="debug-row"><span class="debug-label">voz</span><span class="debug-value" id="debugVoice">verificando…</span></div>',
      '<div class="debug-row"><span class="debug-label">microfone</span><span class="debug-value" id="debugMic">—</span></div>',
      '<div class="debug-row"><span class="debug-label">modo</span><span class="debug-value" id="debugMode">—</span></div>',
      '<div class="debug-row"><span class="debug-label">shell</span><span class="debug-value" id="debugShell">—</span></div>',
      '<div class="debug-row"><span class="debug-label">último comando</span><span class="debug-value" id="debugCommand">—</span></div>',
      '<div class="debug-row"><span class="debug-label">último erro</span><span class="debug-value" id="debugError">—</span></div>',
      "</div>",
      '<div class="debug-block" aria-label="Ações">',
      '<p class="debug-title">ações</p>',
      '<div class="debug-actions">',
      '<button id="debugTestVoice" class="btn" type="button" aria-label="Testar a voz do JARVIS">',
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11 5 6 9H2v6h4l5 4V5Z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M19 5a9 9 0 0 1 0 14"/></svg>',
      "testar voz",
      "</button>",
      '<button id="debugCopy" class="btn" type="button" aria-label="Copiar o diagnóstico para a área de transferência">',
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="8" height="4" x="8" y="2" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/></svg>',
      "copiar diagnóstico",
      "</button>",
      '<button id="debugReload" class="btn" type="button" aria-label="Recarregar o aplicativo">',
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a9 9 0 1 1-2.64-6.36"/><path d="M21 3v6h-6"/></svg>',
      "recarregar app",
      "</button>",
      "</div>",
      "</div>",
      '<div class="debug-block" aria-label="Ajustes">',
      '<p class="debug-title">ajustes</p>',
      '<label class="debug-row debug-toggle"><span>escuta automática</span>',
      '<input id="debugListen" class="debug-switch" type="checkbox" role="switch" aria-label="Escuta automática ligada ou desligada"></label>',
      '<label class="debug-row debug-toggle"><span>modo quieto</span>',
      '<input id="debugQuiet" class="debug-switch" type="checkbox" role="switch" aria-label="Modo quieto ligado ou desligado"></label>',
      appMode ? '<p class="debug-hint">no app do Mac a escuta é gerenciada pelo JARVIS.</p>' : "",
      '<div class="debug-row debug-volume-row"><span class="debug-label" id="debugVolumeLabel">volume da fala</span>',
      '<input id="debugVolume" class="debug-volume" type="range" min="0" max="100" step="5" value="100" aria-labelledby="debugVolumeLabel"></div>',
      "</div>",
    ].join("");
    document.body.appendChild(panel);

    panel.querySelector("#debugClose")?.addEventListener("click", closeDebug);
    panel.querySelector("#debugTestVoice")?.addEventListener("click", () => {
      cancelPark();
      speak("Teste de voz do Jarvis.");
    });
    panel.querySelector("#debugCopy")?.addEventListener("click", copyDebug);
    panel.querySelector("#debugReload")?.addEventListener("click", restartForUpdate);

    const listenToggle = panel.querySelector("#debugListen");
    listenToggle?.addEventListener("change", () => {
      if (listenToggle.checked) startWakeLoop();
      else stopWakeLoop();
    });
    const quietToggle = panel.querySelector("#debugQuiet");
    quietToggle?.addEventListener("change", () => {
      if (quietToggle.checked) {
        enterQuiet();
        return;
      }
      stayQuiet = false;
      say("De volta.", "Pode pedir, senhor.");
    });
    const volume = panel.querySelector("#debugVolume");
    if (volume) {
      volume.value = String(Math.round(webVolume() * 100));
      volume.addEventListener("input", () => {
        try {
          window.localStorage.setItem(WEB_VOLUME_KEY, String(Number(volume.value) / 100));
        } catch { /* private mode */ }
      });
    }

    probeMicPermission();
    const paint = () => {
      const voiceDown = document.documentElement.classList.contains("voice-down");
      const note = document.getElementById("debugVoiceDown");
      if (note) note.hidden = !voiceDown;
      debugSet("debugGateway", debugGatewayText(), debugGatewayState());
      debugSet("debugVoice", debugVoiceText(), debugVoiceState());
      debugSet("debugMic", micPermissionText(), micPermission === "denied" ? "bad" : "");
      debugSet("debugMode", appMode ? "app (Mac)" : "web", "");
      const stale = document.getElementById("buildLine")?.dataset.state === "stale";
      debugSet("debugShell", stale ? `v${SHELL_VERSION} · desatualizada` : `v${SHELL_VERSION}`, stale ? "warn" : "ok");
      debugSet("debugCommand", lastCommand || "—", "");
      debugSet("debugError", lastError || (lastCommand && !lastError ? "nenhum" : "—"), lastError ? "bad" : "");
      if (listenToggle) {
        listenToggle.checked = keepListening;
        listenToggle.disabled = appMode;
      }
      if (quietToggle) quietToggle.checked = stayQuiet;
    };
    paint();
    debugTimer = window.setInterval(paint, 2000);
  }
})();


